collect_data.py
收集spacing为 0.25， 0.25， 3.3的数据，在normalIMG和IMG中

crop_seg.py
crop和降采样，保存crop图像和seg，降采样的crop图像和seg
print(size == seg_size,
              tuple(map(lambda x: round(x, 2), seg_spacing)) == tuple(map(lambda x: round(x, 2), spacing)),
              tuple(map(lambda x: round(x, 2), seg_direction)) == tuple(map(lambda x: round(x, 2), direction)),
              tuple(map(lambda x: round(x, 2), seg_origin)) == tuple(map(lambda x: round(x, 2), origin)))
sagittal文件下数据和org.mha对应不起来的情况，采集了多次的sagittal， seg只用了其中一次的

convert_npy.py
每一个sample的crop_down图像和分割保存为npy