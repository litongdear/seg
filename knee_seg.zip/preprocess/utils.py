import os
import pandas as pd
import shutil
import SimpleITK as sitk
import numpy as np

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def RAS_transform(index_list, origin, spacing, direction):
    direction = np.array(direction)
    direction = np.array(direction.reshape((3, 3)))
    cc = np.transpose(direction, axes=[1, 0])
    dddd = np.array([index_list]) * np.array(spacing)
    t_pixel = np.matmul(dddd, cc)
    t_pixel_v = t_pixel + np.array(origin)
    return t_pixel_v

def axis_transform(index_list, origin, spacing, direction):
    coord = np.array([(np.array(index_list) - np.array(origin))]).reshape((1,3))
    direction = np.array(direction).reshape((3, 3))
    # cc = np.transpose(direction, axes=[1, 0])
    coor_len = np.matmul(coord, direction)/np.array(spacing)
    coor_int = np.around(coor_len[0])
    return coor_int.astype(int)

def writeImg(arr, spacing, origin, direction, path):
    img = sitk.GetImageFromArray(arr)
    img.SetOrigin(origin)
    img.SetSpacing(spacing)
    img.SetDirection(direction)
    sitk.WriteImage(img, path)
    # return img

def get_img_param(img):
    spacing = img.GetSpacing()
    size = img.GetSize()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    arr = sitk.GetArrayFromImage(img)
    return  arr, spacing, size, origin, direction

def resample_func(img_fig, new_spacing, new_size, direction, origin, interp=sitk.sitkLinear):
    resample = sitk.ResampleImageFilter()
    resample.SetInterpolator(interp)  # sitk.sitkLinear
    resample.SetDefaultPixelValue(0)

    resample.SetOutputSpacing(new_spacing)
    resample.SetOutputOrigin(origin)
    resample.SetOutputDirection(direction)
    resample.SetSize(new_size)

    new_img = resample.Execute(img_fig)
    return new_img
