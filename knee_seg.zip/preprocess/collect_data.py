import os
import SimpleITK as sitk
import numpy as np
# import pickle
import scipy.io as scio
from  skimage import  transform
import imageio
import pandas as pd

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def RAS_transform(index_list, origin, spacing, direction):
    direction = np.array(direction)
    direction = np.array(direction.reshape((3, 3)))
    cc = np.transpose(direction, axes=[1, 0])
    dddd = np.array([index_list]) * np.array(spacing)
    t_pixel = np.matmul(dddd, cc)
    t_pixel_v = t_pixel + np.array(origin)
    return t_pixel_v

def axis_transform(index_list, origin, spacing, direction):
    coord = np.array([(np.array(index_list) - np.array(origin))]).reshape((1,3))
    coor_len = np.matmul(coord, np.array(direction).reshape((3, 3)))/np.array(spacing)
    return coor_len[0].astype(int)

def cal_rawdir(raw_dir):
    n = 0
    img_list = []
    for dir in os.listdir(raw_dir):
        if os.path.exists(os.path.join(raw_dir, dir, dir+'.nii.gz')):
            tmp_path = os.path.join(raw_dir, dir, dir+'.nii.gz')
            img = sitk.ReadImage(os.path.join(tmp_path, 'org.mha'))
            seg = sitk.ReadImage(os.path.join(tmp_path, 'seg.mha'))

            spacing = img.GetSpacing()
            size = img.GetSize()
            origin = img.GetOrigin()
            direction = img.GetDirection()

            img_arr = sitk.GetArrayFromImage(img)
            seg_arr = sitk.GetArrayFromImage(seg)

            if spacing[0] == 0.25 and spacing[2]==3.3:
                print(spacing, size)
                n = n +1
                img_list.append(dir)
    print(n)
    return img_list

def cal_IMG(IMG_dir):
    n = 0
    img_list = []
    for dir in os.listdir(IMG_dir):
        dir_path = os.path.join(IMG_dir, dir)
        file_path = os.path.join(IMG_dir, dir, 'Sagittal', dir+'.nii.gz')
        img = sitk.ReadImage(file_path)

        spacing = img.GetSpacing()
        size = img.GetSize()
        origin = img.GetOrigin()
        direction = img.GetDirection()

        img_arr = sitk.GetArrayFromImage(img)
        # print(dir, spacing, size)
        if round(spacing[0], 2) == 0.25 and round(spacing[2], 1) == 3.3:
            n = n +1
            img_list.append(dir)
            print(dir, spacing, size)
    print(IMG_dir, n)
    return img_list

if __name__=='__main__':
    raw_dir1 = '/share/litong/knee/normal_IMG/'  # raw 251 IMG 417 normal_IMG  86(0.25, 3.3) 88(0.33, 3.3)
    raw_dir2 = '/share/litong/knee/IMG/'
    blur_path = '/share/litong/knee/blur_seg/'
    blur_data = blur_path + '/data/'
    path_exist(blur_path)
    path_exist(blur_data)
    seg_spac = []
    n_list = cal_IMG(raw_dir1)
    g_list = cal_IMG(raw_dir2)
    seg_spac = seg_spac + n_list+g_list
    file_pd = pd.DataFrame({'num': seg_spac})
    file_pd.to_csv('/share/litong/knee/0.25_3.3.csv', index=None)

