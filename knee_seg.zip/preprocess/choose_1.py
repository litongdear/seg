import  os

base_dir = 'E:\KneeImages\ShangHai6'
for dir in os.listdir(base_dir):
    if os.path.isdir(os.path.join(base_dir, dir)):
        for subdir in os.listdir(os.path.join(base_dir, dir)):
            if os.path.isdir(os.path.join(base_dir, dir, subdir)):
                for ssdir in os.listdir(os.path.join(base_dir, dir, subdir)):
                    file_num = len(os.listdir(os.path.join(base_dir, dir, subdir, ssdir)))
                    # if file_num > 150:
                    print(file_num, os.path.join(base_dir, dir, subdir, ssdir))
