import os
import SimpleITK as sitk
# from preprocess.utils import axis_transform, get_img_param, writeImg
import numpy as np

def get_img_param(img):
    spacing = img.GetSpacing()
    size = img.GetSize()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    arr = sitk.GetArrayFromImage(img)
    return  arr, spacing, size, origin, direction

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def para_func(origin, center):
    para_list = []
    for i, j in zip(origin, center):
        if i < j:
            para_list.append(-1)
        else:
            para_list.append(1)
    return np.array(para_list)

def resample_func(img_fig, new_spacing, new_size, direction,
                  origin, interp=sitk.sitkLinear):
    resample = sitk.ResampleImageFilter()
    resample.SetInterpolator(interp)  # sitk.sitkLinear
    resample.SetDefaultPixelValue(0)

    resample.SetOutputSpacing(new_spacing)
    resample.SetOutputOrigin(origin)
    resample.SetOutputDirection(direction)
    resample.SetSize(new_size)

    new_img = resample.Execute(img_fig)
    return new_img


def RAS_transform(index_list, origin, spacing, direction):
    direction = np.array(direction)
    direction = np.array(direction.reshape((3, 3)))
    cc = np.transpose(direction, axes=[1, 0])
    dddd = np.array([index_list]) * np.array(spacing)
    t_pixel = np.matmul(dddd, cc)
    t_pixel_v = t_pixel + np.array(origin)
    return t_pixel_v[0]

def center_transform(index_list, center, spacing, direction):
    direction = np.array(direction)
    direction = np.array(direction.reshape((3, 3)))
    cc = np.transpose(direction, axes=[1, 0])
    dddd = -np.array([index_list]) * np.array(spacing)
    t_pixel = np.matmul(dddd, cc)
    t_pixel_v = t_pixel + np.array(center)
    return t_pixel_v[0]

if __name__=='__main__':
    raw_dir1 = 'E:\knee_data\\normal_IMG\\'  # raw 251 IMG 417 normal_IMG  86(0.25, 3.3) 88(0.33, 3.3)
    raw_dir2 = 'E:\knee_data\IMG\IMG\\'
    save_path = 'E:\knee_data\standard_1\\'
    # seg_path = '/share/litong/knee/spacing_seg/'

    path_exist(save_path)
    pl_list = ['Axial', 'Sagittal', 'Coronal']
    a_d = [1, 0, 0, 0, 1, 0, 0, 0, 1]
    s_d = [0, 0, -1, 1, 0, 0, 0, -1, 0]
    c_d = [1, 0, 0, 0, 0, 1, 0, -1, 0]
    direction_list = [a_d, s_d, c_d]

    for datadir in [raw_dir1, raw_dir2]:
        for dir in os.listdir(datadir):
            a_path = os.path.join(datadir, dir, 'Axial', dir + '.nii.gz')
            s_path = os.path.join(datadir, dir, 'Sagittal', dir + '.nii.gz')
            c_path = os.path.join(datadir, dir, 'Coronal', dir + '.nii.gz')
            print(dir)

            # for imgpath, pl, d in zip([s_path], pl_list, direction_list):
            imgpath, pl, d = s_path, 'Sagittal', s_d
            img = sitk.ReadImage(imgpath)
            arr, spacing, size, origin, direction = get_img_param(img)
            center_point = np.array(size)//2-1
            center_cood = RAS_transform(center_point, origin, spacing, direction)
            # para = para_func(origin, center_cood)
            new_origin = center_transform(center_point, center_cood, spacing, d)
            new_img = resample_func(img, spacing, size, d, new_origin)
            # print(np.array(direction).reshape((3, 3)))
            # save_dir = os.path.join(save_path, dir)
            # path_exist(save_dir)
            if pl=='Sagittal':
                save_name = os.path.join(save_path, dir + '.mhd')
                sitk.WriteImage(new_img, save_name)


                # if os.path.exists(os.path.join(seg_path, dir+'_seg.mha')) and pl=='Sagittal':
                #     seg_img = sitk.ReadImage(os.path.join(seg_path, dir+'_seg.mha'))
                    # seg_arr, spacing, size, origin, direction = get_img_param(seg_img)
                    # center_point = np.array(size) // 2 - 1
                    # center_cood = RAS_transform(center_point, origin, spacing, direction)
                    #
                    # new_origin = center_transform(center_point, center_cood, spacing, d)
                    # new_seg_img = resample_func(seg_img, spacing, size, d, new_origin, interp=sitk.sitkNearestNeighbor)
                    # new_seg_img = resample_func(seg_img, spacing, size, d, new_origin, interp=sitk.sitkNearestNeighbor)
                    # seg_save_name = os.path.join(save_dir, dir + '_seg' + '.nii.gz')
                    # seg_save_name1 = os.path.join(save_dir, dir + '_seg' + '.mha')
                    # sitk.WriteImage(new_seg_img, seg_save_name1)
                    # sitk.WriteImage(new_seg_img, seg_save_name)


