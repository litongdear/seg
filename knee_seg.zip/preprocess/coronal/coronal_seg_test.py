import os
import SimpleITK as sitk
import numpy as np
import pandas as pd

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def RAS_transform(index_list, origin, spacing, direction):
    direction = np.array(direction)
    direction = np.array(direction.reshape((3, 3)))
    cc = np.transpose(direction, axes=[1, 0])
    dddd = np.array([index_list]) * np.array(spacing)
    t_pixel = np.matmul(dddd, cc)
    t_pixel_v = t_pixel + np.array(origin)
    return t_pixel_v

def axis_transform(index_list, origin, spacing, direction):
    coord = np.array([(np.array(index_list) - np.array(origin))]).reshape((1,3))
    direction = np.array(direction).reshape((3, 3))
    # cc = np.transpose(direction, axes=[1, 0])
    coor_len = np.matmul(coord, direction)/np.array(spacing)
    coor_int = np.around(coor_len[0])
    return coor_int.astype(int)

def writeImg(arr, spacing, origin, direction, path):
    img = sitk.GetImageFromArray(arr)
    img.SetOrigin(origin[0])
    img.SetSpacing(spacing)
    img.SetDirection(direction)
    sitk.WriteImage(img, path)
    # return img

def get_img_param(img):
    spacing = img.GetSpacing()
    size = img.GetSize()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    arr = sitk.GetArrayFromImage(img)
    return  arr, spacing, size, origin, direction

def resample_func(img_fig, new_spacing, new_size, direction, origin, interp=sitk.sitkLinear):
    resample = sitk.ResampleImageFilter()
    resample.SetInterpolator(interp)  # sitk.sitkLinear
    resample.SetDefaultPixelValue(0)

    resample.SetOutputSpacing(new_spacing)
    resample.SetOutputOrigin(origin)
    resample.SetOutputDirection(direction)
    resample.SetSize(new_size)

    new_img = resample.Execute(img_fig)
    return new_img

seg_path = '/share/litong/knee/spacing_seg/'
data_dir1 = '/share/litong/knee/IMG/'
data_dir2 = '/share/litong/knee/normal_IMG/'
sagittal_s = '/share/litong/knee/blur_seg/seg_crop_down_10/'
save_coronal_path = '/share/litong/knee/blur_seg/coronal_npy/coronal_seg_data_test/'
save_data_npy_train = '/share/litong/knee/blur_seg/coronal_npy/test_data_all/'
save_seg_npy_train = '/share/litong/knee/blur_seg/coronal_npy/test_seg/'

csv_path = '/share/litong/knee/0.25_3.3.csv'
file_pd = pd.read_csv(csv_path)
file_list = file_pd['num'].values

path_exist(save_coronal_path)
path_exist(save_seg_npy_train)
path_exist(save_data_npy_train)

Coronal_target = [0.306, 0.306, 4]
coronal_size = [528, 528, 20]
crop_size = 320

# for dir in os.listdir(data_dir1):
#     coronal_path = os.path.join(data_dir1, dir, 'Coronal', dir +'.nii.gz')
#     coronal_img = sitk.ReadImage(coronal_path)
#     coronal_spacing = coronal_img.GetSpacing()
#     coronal_size = coronal_img.GetSize()
#     print(dir, coronal_spacing, coronal_size)
# for dir in os.listdir(data_dir2):
#     coronal_path = os.path.join(data_dir2, dir, 'Coronal', dir +'.nii.gz')
#     coronal_img = sitk.ReadImage(coronal_path)
#     coronal_spacing, coronal_size, coronal_origin, coronal_d = get_img_param(coronal_img)
#
#     print(dir, coronal_spacing, coronal_size)

for dir_num in file_list[200:]:
    dir = str(dir_num).zfill(5)
# for dir in os.listdir(sagittal_s):
    if dir in os.listdir(data_dir1):
        coronal_path = os.path.join(data_dir1, dir, 'Coronal', dir + '.nii.gz')
    elif dir in os.listdir(data_dir2):
        coronal_path = os.path.join(data_dir2, dir, 'Coronal', dir + '.nii.gz')

    coronal_img = sitk.ReadImage(coronal_path)
    coronal_arr, coronal_spacing, coronal_size, coronal_origin, coronal_d = get_img_param(coronal_img)
    if round(coronal_spacing[0], 3) == 0.306 and round(coronal_spacing[2], 1) == 4.0 \
            and coronal_size[0]==528 and coronal_size[2]==20:
        seg_img = sitk.ReadImage(os.path.join(seg_path, dir+'_seg.mha'))
        # seg_img = sitk.ReadImage(os.path.join(data_dir2, dir, 'Sagittal', dir + '.nii.gz'))
        seg_arr, seg_spacing, seg_size, seg_origin, seg_d = get_img_param(seg_img)

        new_origin_index = [0, 0, min(seg_size)-1]
        new_spacing = [max(seg_spacing), min(seg_spacing), min(seg_spacing)]
        new_size = [min(seg_size), max(seg_size), max(seg_size)]

        new_origin = RAS_transform(new_origin_index, seg_origin, seg_spacing, seg_d)  # clear sge_mask convert to coronal
        new_seg = resample_func(seg_img, new_spacing, new_size, coronal_d, new_origin[0], interp=sitk.sitkNearestNeighbor)

        coronal_seg = resample_func(seg_img, coronal_spacing, coronal_size, coronal_d, coronal_origin,
                                    interp=sitk.sitkNearestNeighbor)  # blur sge_mask convert to coronal
        coronal_seg_arr = sitk.GetArrayFromImage(coronal_seg)

        save_dir = os.path.join(save_coronal_path, dir)
        path_exist(save_dir)
        # sitk.WriteImage(new_seg, os.path.join(save_dir, dir +'_seg_to_conronal.nii.gz'))
        print(dir)

        dict_sa = {}
        for i in range(min(seg_size)):
            index_i = [i, 0, max(seg_size)-1]
            index_v_1 = RAS_transform(index_i, new_origin, new_spacing, coronal_d)
            index_v_2 = axis_transform(index_v_1, coronal_origin, coronal_spacing, coronal_d)
            dict_sa[i] = [index_v_2[0]]

            # s = [index_v_2[0], 103, 0]
            # u = [index_v_2[0], 423, 19]
            #
            # for m in [s, u]:
            #     index_v_m = RAS_transform(m, coronal_origin, coronal_spacing, coronal_d)
            #     index_v_2m = axis_transform(index_v_m, new_origin, new_spacing, coronal_d)
            #     dict_sa[i].append(list(index_v_2m))
        print('lll')

        coronal_new_arr = np.zeros((20, 320, min(seg_size)))
        seg_new_arr = np.zeros((20, 320, min(seg_size)))
        new_seg_origin_index = [dict_sa[0][0], 0, 103]
        new_seg_origin = RAS_transform(new_seg_origin_index, coronal_origin, coronal_spacing, coronal_d)
        new_seg_size = [min(seg_size), max(coronal_size), 20]
        new_seg_spacing = [min(coronal_spacing)*(527)/min(seg_size), min(coronal_spacing), max(coronal_spacing)]

        for k, v in dict_sa.items():
            coronal_new_arr[ :, :, k] = coronal_arr[ :, 103:423, v[0]]
            seg_new_arr[:, :, k] = coronal_seg_arr[:, 103:423, v[0]]
            seg_name = os.path.join(save_seg_npy_train, dir+'_'+str(v[0])+'_seg'+'.npy')
            np.save(seg_name, coronal_seg_arr[:, 103:423, v[0]])

        save_name1 = os.path.join(save_dir, dir+'_new_crop.nii.gz')
        save_name2 = os.path.join(save_dir, dir + '_new_seg_crop.nii.gz')
        # writeImg(coronal_new_arr, new_seg_spacing, new_seg_origin, coronal_d, save_name1)
        # writeImg(seg_new_arr, new_seg_spacing, new_seg_origin, coronal_d, save_name2)

        crop_origin_index = [0, 0, 103]
        crop_origin = RAS_transform(crop_origin_index, coronal_origin, coronal_spacing, coronal_d)
        crop_arr = coronal_arr[:, 103:423, :]
        # save_name3 = os.path.join(save_dir, dir + '_crop.nii.gz')
        # writeImg(crop_arr, coronal_spacing, crop_origin, coronal_d, save_name3)

        save_data_npy_train_dir = os.path.join(save_data_npy_train, dir)
        path_exist(save_data_npy_train_dir)
        for i in range(crop_arr.shape[2]):
            img_tmp_arr = crop_arr[:, :, i]
            img_tmp_name = os.path.join(save_data_npy_train_dir, dir+'_'+str(i)+'.npy')
            print(img_tmp_arr.shape)
            np.save(img_tmp_name, img_tmp_arr)


