import pandas as pd
import numpy as np
import os
import nibabel as nib

csv_path = '/share/litong/knee/cycle_seg/data/train.csv'
raw_path = '/share/litong/knee/cycle_seg/data/crop/'
save_npy = '/share/litong/knee/cycle_seg/data/crop_sagittal_npy/'

df = pd.read_csv(csv_path)
images_list = []
images_list += [str(line).zfill(5) for line in list(df['train'].values)]

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

path_exist(save_npy)
for file in images_list:
    s, seg = [nib.load(os.path.join(raw_path, file, file + '_' + pos + '.nii.gz'))
                for pos in ['sagittal_sp', 'seg_sp']]
    s_data = s.get_fdata()
    seg_data = seg.get_data()

    # save_dir = os.path.join(save_npy, file)
    path_exist(save_npy)
    for i in range(s_data.shape[0]):
        tmp_s = s_data[None, i, :, :]
        tmp_seg = seg_data[None,i, :, :]
        tmp = np.concatenate((tmp_s, tmp_seg),0)
        save_name = os.path.join(save_npy, file+'_'+str(i)+'.npy')
        np.save(save_name, tmp)
