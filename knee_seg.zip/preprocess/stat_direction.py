import os
import SimpleITK as sitk
from preprocess.utils import RAS_transform, axis_transform, resample_func, get_img_param, writeImg, path_exist
import numpy as np

if __name__=='__main__':
    raw_dir1 = '/share/litong/knee/normal_IMG/'  # raw 251 IMG 417 normal_IMG  86(0.25, 3.3) 88(0.33, 3.3)
    raw_dir2 = '/share/litong/knee/IMG/'
    for datadir in [raw_dir1, raw_dir2]:
        for dir in os.listdir(datadir):
            print(dir)
            a_path = os.path.join(datadir, dir, 'Axial', dir+'.nii.gz')
            s_path = os.path.join(datadir, dir, 'Sagittal', dir + '.nii.gz')
            c_path = os.path.join(datadir, dir, 'Coronal', dir + '.nii.gz')
            for pl in [a_path, s_path, c_path]:
                arr, spacing, size, origin, direction = get_img_param(sitk.ReadImage(pl))
                print(np.array(direction).reshape((3, 3)))

