import os
import SimpleITK as sitk
from preprocess.utils import *
base_dir = '/share/litong/knee/normal_IMG/00067/'
seg_dir = '/share/litong/knee/spacing_seg/'
dd_dir = '/share/litong/knee/tmp_sample/'
path_exist(dd_dir)

sagittal_img = sitk.ReadImage(os.path.join(base_dir,'Sagittal', '00067.nii.gz'))
coronal_img = sitk.ReadImage(os.path.join(base_dir,'Coronal', '00067.nii.gz'))

coronal_arr, coronal_spacing, coronal_size, coronal_origin, coronal_d = get_img_param(coronal_img)
seg_arr, seg_spacing, seg_size, seg_origin, seg_d = get_img_param(sagittal_img)

coronal_d_1 = np.array(coronal_d).reshape((3,3))
coronal_d_2 = np.zeros((3, 3))
coronal_d_2[:, 2] = -coronal_d_1[:, 0]
coronal_d_2[:, 0] = coronal_d_1[:, 2]
coronal_d_2[:, 1] = coronal_d_1[:, 1]
print(coronal_d_2)
coronal_d_2 = coronal_d_2.reshape(-1)
print(np.array(seg_d).reshape((3,3)))
print(np.array(coronal_d).reshape((3,3)))

s_img_new = resample_func(sagittal_img, seg_spacing, seg_size, coronal_d_2, seg_origin)
sitk.WriteImage(s_img_new, dd_dir+'00067_1.nii.gz')
print('mmm')
