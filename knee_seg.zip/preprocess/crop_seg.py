import os
import pandas as pd
import shutil
import SimpleITK as sitk
import numpy as np

csv_path = '/share/litong/knee/0.25_3.3.csv'
seg_path = '/share/litong/knee/spacing_seg/'
data_seg = '/share/litong/knee/blur_seg/seg_crop_down_10/'
data1 = '/share/litong/knee/IMG/'
data2 = '/share/litong/knee/normal_IMG/'

data1_list = os.listdir(data1)
data2_list = os.listdir(data2)

file_pd = pd.read_csv(csv_path)
file_list = file_pd['num'].values

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def RAS_transform(index_list, origin, spacing, direction):
    direction = np.array(direction)
    direction = np.array(direction.reshape((3, 3)))
    cc = np.transpose(direction, axes=[1, 0])
    dddd = np.array([index_list]) * np.array(spacing)
    t_pixel = np.matmul(dddd, cc)
    t_pixel_v = t_pixel + np.array(origin)
    return t_pixel_v

def writeImg(arr, spacing, origin, direction, path):
    img = sitk.GetImageFromArray(arr)
    img.SetOrigin(origin[0])
    img.SetSpacing(spacing)
    img.SetDirection(direction)
    sitk.WriteImage(img, path)
    # return img

crop_size = 321
ratio = 10
for num in file_list[:200]:
    number = str(num).zfill(5)
    if number in data1_list:
        file_path = os.path.join(data1, number, 'Sagittal', number + '.nii.gz')
    elif number in data2_list:
        file_path = os.path.join(data2, number, 'Sagittal', number + '.nii.gz')

    img = sitk.ReadImage(file_path)
    spacing = img.GetSpacing()
    size = img.GetSize()
    origin = img.GetOrigin()
    direction = img.GetDirection()

    seg_path_file = os.path.join(seg_path, number+'_seg.mha')
    seg_img = sitk.ReadImage(seg_path_file)
    seg_origin = seg_img.GetOrigin()
    seg_size = seg_img.GetSize()
    seg_spacing = seg_img.GetSpacing()
    seg_direction = seg_img.GetDirection()

    if (size == seg_size and
          tuple(map(lambda x: round(x, 2), seg_spacing)) == tuple(map(lambda x:round(x, 2), spacing)) and
          tuple(map(lambda x: round(x, 2), seg_direction)) == tuple(map(lambda x: round(x, 2), direction)) and
          tuple(map(lambda x: round(x, 2), seg_origin)) == tuple(map(lambda x: round(x, 2), origin))) :

        img_arr = sitk.GetArrayFromImage(img)
        seg_arr = sitk.GetArrayFromImage(seg_img)
        print(number, img_arr.shape, seg_arr.shape)

        center_crop_x, center_crop_y = size[0]//2, size[1]//2
        start_x, start_y = center_crop_x-crop_size//2-1, center_crop_y-crop_size//2-1

        new_origin_index = [start_x, start_y, 0]
        new_origin = RAS_transform(new_origin_index, origin, spacing, direction)
        img_crop_arr= img_arr[:, start_x:start_x+crop_size, start_y:start_y+crop_size]
        seg_crop_arr = seg_arr[:, start_x:start_x + crop_size, start_y:start_y + crop_size]

        path_exist(os.path.join(data_seg, number))
        writeImg(img_crop_arr, spacing, new_origin, direction, os.path.join(data_seg, number, number+'_img_crop.nii.gz'))
        writeImg(seg_crop_arr, spacing, new_origin, direction, os.path.join(data_seg, number, number + '_seg_crop.nii.gz'))

        img_down_arr = img_crop_arr[:, ::ratio, :]
        seg_down_arr = seg_crop_arr[:, ::ratio, :]
        new_spacing = [spacing[0], spacing[1]*(crop_size-1)/((crop_size-1)/ratio-1), spacing[2]]
        writeImg(img_down_arr, new_spacing, new_origin, direction, os.path.join(data_seg, number, number + '_img_crop_down.nii.gz'))
        writeImg(seg_down_arr, new_spacing, new_origin, direction, os.path.join(data_seg, number, number + '_seg_crop_down.nii.gz'))

    else:
        print(size == seg_size,
              tuple(map(lambda x: round(x, 2), seg_spacing)) == tuple(map(lambda x: round(x, 2), spacing)),
              tuple(map(lambda x: round(x, 2), seg_direction)) == tuple(map(lambda x: round(x, 2), direction)),
              tuple(map(lambda x: round(x, 2), seg_origin)) == tuple(map(lambda x: round(x, 2), origin)))
        print(number,': not the same file')
    # print('mmm')
    # print('mmm')

