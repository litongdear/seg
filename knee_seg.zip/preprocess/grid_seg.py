import torch
from utils import nii_func
import pandas as pd

def grid_sample_mask(s, image):
    # s_data = s.get_fdata()
    # s_affine = s.affine
    scale_factor = 13
    s_shape = s.get_shape()
    mask = torch.zeros((s_shape[0] - 1) * scale_factor + 1, s_shape[1], s_shape[2])
    mask[::scale_factor, :, :] = 1

    grid = nii_func.affine2Grids_original(image.affine, image.shape, s)
    # coronal_mask_tensor = torch.Tensor(c.get_data().T)

    mask_tensor = mask.permute(2, 1, 0)

    a_grid = torch.Tensor(grid[0][0])
    print(mask.shape, a_grid.shape)
    a_mask = torch.nn.functional.grid_sample(mask_tensor.unsqueeze(0).unsqueeze(0),
                                             a_grid.unsqueeze(0), mode='nearest')
    a_mask_arr = a_mask.squeeze().permute(2, 1, 0)
    return a_mask_arr

csv_path = '/share/litong/knee/cycle_seg/data/train.csv'
images = []
df = pd.read_csv(csv_path)
images += [str(line).zfill(5) for line in list(df['train'].values)]
