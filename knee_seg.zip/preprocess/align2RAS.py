#!python3
import numpy as np
import nibabel as nib
import csv
import math
import random
import os.path

def shape2verticesInd(shape, homogeneous=False):
    assert len(shape) == 3
    vertices = np.mgrid[0:2,0:2,0:2].reshape(3,-1).T*shape
    if homogeneous:
        vertices = np.concatenate([vertices, np.ones((8,1))], 1)
    return vertices

def is_inside(image, affine, shape):
    img_shape = image.get_shape()
    img_affine = image.affine
    patch_vertex_in_image = \
            np.linalg.inv(img_affine) @ affine \
            @ shape2verticesInd(shape, homogeneous=True).T
    ind_pos = patch_vertex_in_image[:3,:]
    ind_neg = ind_pos - (np.array(img_shape) - 1).reshape(3,1)
    return ind_pos.min()>=0 and ind_neg.max()<=0

def crop(image, ranges, pad=[0,0,0], ratio=[1,1,1]):
    '''
    ranges: [[x_start, x_stop), [y_start, y_stop), [z_start, z_stop)]
    '''
    assert isinstance(image, nib.analyze.AnalyzeImage)
    #ranges = np.ceil(ranges).astype(np.int)
    # print(ranges)
    shape = image.shape
    newRanges = []
    for r,p,s,n in zip(ranges, pad, shape, ratio):
        middle = (r[0]+r[1])/2.0
        length = math.ceil((r[1] - r[0] + p*2)/float(n))*n
        assert length <= s
        minVal = math.floor(max(middle-length/2.0, 0))
        maxVal = min(minVal+length, s)
        minVal = maxVal - length
        newRanges.append((minVal, maxVal))
    ranges = np.array(newRanges)
    data = image.get_data()
    affine = image.affine.copy()
    data = data[ranges[0,0]:ranges[0,1], \
            ranges[1,0]:ranges[1,1], ranges[2,0]:ranges[2,1]]
    origin = nib.affines.apply_affine(affine, ranges[:,0])
    affine[0:3,3] = origin
    return nib.Nifti1Image(data.copy(), affine)

def getVertices(image):
    shape = image.get_shape()
    affine = image.affine
    vertices = np.mgrid[0:2,0:2,0:2].reshape(3,-1).T*(np.array(shape)-1)
    vertices = np.concatenate([vertices, np.ones((8,1))], 1)
    return affine@vertices.T

def getIntersection(image, *constrains, strict=0):
    '''
    get common cube of a image and several constrains
        assuming they are orthogonal
    strict: (exactly intersection) 0 - 1 - 2 - 3 (rought intersection)
    return: a list of 2-tuple indicating
        the starting and ending index (with regard to image)
        of x,y,z seperately
    '''
    D = 3 # dimensionanlity
    N = 8 # number of vertices
    affine = np.array(image.affine)
    shape = np.array(image.get_shape())
    inv_affine = np.linalg.inv(affine)
    valid_ranges = np.array(list(zip([.0]*D, shape-1))) #x,y,z range seperately
    for constrain in constrains:
        vertices = inv_affine@getVertices(constrain).tolist()
        print('---------------')
        print(vertices)
        for dim in range(D):
            coord = sorted(vertices[dim])
            valid_ranges[dim,0] = \
                    max(valid_ranges[dim,0], coord[N//2-1-strict])
            valid_ranges[dim,1] = \
                    min(valid_ranges[dim,1], coord[N//2+strict])
    print(valid_ranges)
    return valid_ranges

def getSpacing(image):
    D = 3
    return image.get_header()['pixdim'][1:D+1]

def randomPatchAffine(refImg, *images, spacing, shape):
    '''
    Sample small patches in the same physical coordinate.
    return patch physical coordinate affines
    '''
    D = 3
    spacing = np.array(spacing)
    shape = np.array(shape)
    valid_ranges = getIntersection(refImg, *images)
    # get reference image voxel spacing
    refSpacing = getSpacing(refImg)
    valid_ranges[:,1] -= spacing*shape/refSpacing
    delta_ranges = valid_ranges[:,1] - valid_ranges[:,0]
    #print(delta_ranges)
    assert all(delta_ranges >= 0), \
            'impossible to sample patch'
    origin = np.random.random((D,)) * delta_ranges + valid_ranges[:,0]
    affine = np.eye(D+1)
    affine[0:3,3] += origin
    affine[:,0:3] *= spacing/refSpacing
    affineRef = refImg.affine@affine
    return affineRef

def affine2Grids(affine, shape, *images):
    # shape shoud be in (x, y, z) order
    basegrid = np.meshgrid( \
            *[np.arange(n) for n in shape], indexing='ij')
    basegrid.append(np.ones_like(basegrid[0]))
    basegrid = np.stack(basegrid).reshape(4,-1)
    grids = []
    for image in images:
        grid = (np.linalg.inv(image.affine)@affine)@basegrid
        grid = grid[0:3,:].reshape(3,*shape)
        grid = grid/(np.array(image.get_shape())-1).reshape(3,1,1,1)*2 - 1
        invgrid = np.meshgrid( \
                *[np.arange(n) for n in image.get_shape()], indexing='ij')
        invgrid.append(np.ones_like(invgrid[0]))
        invgrid = np.stack(invgrid).reshape(4,-1)
        invgrid = (np.linalg.inv(affine)@image.affine)@invgrid
        invgrid = invgrid[0:3,:].reshape(3,*image.get_shape())
        invgrid = invgrid/(np.array(shape)-1).reshape(3,1,1,1)*2 - 1
        grids.append((grid.T, invgrid.T))
    return grids

def randomPatchGrids(refImg, *images, spacing, shape):
    '''
    return a grid (and it's inverse grid) to be used in
        torch.nn.functional.grid_sample
    shape shoud be in (x, y, z) order
    '''
    # find patch from intersection
    #affine = randomPatchAffine(refImg, *images, spacing=spacing, shape=shape)
    # find patch by sampling
    max_trials = 100
    while True:
        affine = randomPatchAffine(refImg, spacing=spacing, shape=shape)
        if all([is_inside(image, affine, shape) for image in images]):
            #print('trial left: ', max_trials)
            break
        assert max_trials >= 0, 'maximum trial exceed'
        max_trials -= 1
        print(max_trials)
    return affine2Grids(affine, shape, refImg, *images)

if __name__ == '__main__':
    import sys
    axial_path = '/share/litong/knee/sample/10903/Axial/10903.nii.gz'
    coronal_path = '/share/litong/knee/sample/10903/Coronal/10903.nii.gz'
    sagittal_path = '/share/litong/knee/sample/10903/Sagittal/10903.nii.gz'
    save_path = '/share/litong/knee/sample/10903/'

    coronal_img = nib.load(coronal_path)
    sagittal_img = nib.load(sagittal_path)
    axial_img = nib.load(axial_path)

    _coronal_img = crop(coronal_img, getIntersection(coronal_img, sagittal_img, axial_img, strict=3))
    _sagittal_img = crop(sagittal_img, getIntersection(sagittal_img, coronal_img, axial_img, strict=3))
    _axial_img = crop(axial_img, getIntersection(axial_img, sagittal_img, coronal_img, strict=3))

    nib.save(_axial_img, os.path.join(save_path, 'Axial', '10903_crop.nii.gz'))
    nib.save(_coronal_img, os.path.join(save_path, 'Coronal', '10903_crop.nii.gz'))
    nib.save(_sagittal_img, os.path.join(save_path, 'Sagittal', '10903_crop.nii.gz'))

    grids = randomPatchGrids(_sagittal_img, _coronal_img, _axial_img, \
            spacing=[0.25]*3, shape=[64]*3)
    ref = (_axial_img, _sagittal_img, _coronal_img)[random.randrange(3)]
    import torch
    # W,H,D,3 -> D,H,W,3
    grid = grids[0][0]
    invgrid = grids[0][1]
    data = sagittal_img.get_data().T
    #dataz = np.ones_like(data)*np.arange(data.shape[0]).reshape(data.shape[0],1,1)/data.shape[0]
    #datay = np.ones_like(data)*np.arange(data.shape[1]).reshape(1,data.shape[1],1)/data.shape[1]
    #datax = np.ones_like(data)*np.arange(data.shape[2]).reshape(1,1,data.shape[2])/data.shape[2]
    quantile = 0.0005
    minVal, maxVal = np.quantile(data, (quantile, 1-quantile))
    data = (data-minVal)/(maxVal-minVal)
    invgrid, grid, data = \
            torch.Tensor(invgrid), torch.Tensor(grid), torch.Tensor(data)
    patch = torch.nn.functional.grid_sample( \
            data.unsqueeze(0).unsqueeze(0), grid.unsqueeze(0))
    patch = patch.reshape(*[64]*3)
    sys.exit(0)

def align2RAS(image):
    # align (+x,+y,+z) to (R, A, S)
    eps = 1e-4
    data = image.get_data()
    affine = image.affine
    unitX, unitY, unitZ = list(map(lambda x: x/np.linalg.norm(x), \
            (affine[0:3,0], affine[0:3,1], affine[0:3,2])))
    # make sure it's square image
    assert  abs(unitX@unitY) < eps
    assert  abs(unitX@unitZ) < eps
    assert  abs(unitY@unitZ) < eps
    return nib.as_closest_canonical(image)

from data.base_dataset import BaseDataset
import torch
class PatchDataset(BaseDataset):
    @staticmethod
    def modify_commandline_options(parser, is_train):
        parser.add_argument('--dataIndex', required=True, type=str, nargs='*',\
                help='csv file(s) containing ID, axial, sagittal, coronal')
        parser.add_argument('--patchSpacing', default=0.25, \
                type=float, metavar='mm', \
                help='patch voxel spacing for x,y,z in mm')
        parser.add_argument('--patchSize', default=128,\
                type=int, metavar='N', \
                help='patch size for x,y,z')
        return parser

    def initialize(self, opt):
        '''
        image: a list of tuples each containing image paths in same order
            (Axial, Sagittal, Coronal)
        '''
        self.gt = []
        self.images = []
        for dataIndex in opt.dataIndex:
            basedir = os.path.dirname(dataIndex)
            with open(dataIndex) as f:
                func = lambda xs: [os.path.join(basedir, x) for x in xs]
                lines = list(map(func, csv.reader(f)))
            self.gt += [line[0] for line in lines]
            self.images += [line[1:] for line in lines]
        self.patchSize = opt.patchSize
        self.patchSpacing = opt.patchSpacing

    def __getitem__(self, index):
        return self._getitem(index)
        try:
            return self._getitem(index)
        except Exception as e:
            print('error happened during handling', self.images[index])
            print(e)

    def _getitem(self, index):
        '''
        output: gt, images, grids, invgrids, axes
        images = (image_a, image_s, image_c)
            out-of-plane axis first
        grids = (grid_a, grid_s, grid_c)
        invgrids = (invgrid_a, invgrid_s, invgrid_c)
        axes = (axis_a, axis_s, axis_c)
            which axis in patch is aligned to out-of-plane axis in image
        '''
        #axial, sagittal, coronal
        try:
            gt = align2RAS(nib.load(self.gt[index]))
        except FileNotFoundError as e:
            gt = None
        a, s, c = [align2RAS(nib.load(path)) for path in self.images[index]]
        quantile = 0.0005
        minVal, maxVal = np.quantile(np.concatenate([img.get_data().ravel() \
                for img in (a,s,c)]), (quantile, 1-quantile))
        #crop to minimal size
        _c = crop(c, getIntersection(c, a, s, strict=3))
        _s = crop(s, getIntersection(s, a, c, strict=3))
        _a = crop(a, getIntersection(a, s, c, strict=3))
        a, s, c = _a, _s, _c
        spacing = [self.patchSpacing]*3
        shape = [self.patchSize]*3
        if gt is not None:
            assert gt.get_data_dtype() == a.get_data_dtype() == \
                    s.get_data_dtype() == c.get_data_dtype()
            ref = gt
        else:
            assert a.get_data_dtype() == \
                    s.get_data_dtype() == c.get_data_dtype()
            ref = (a, s, c)[random.randrange(3)]
        max_trials = 100
        while True:
            affine = randomPatchAffine(ref, spacing=spacing, shape=shape)
            if all([is_inside(image, affine, shape) for image in (a,s,c)]):
                break
            assert max_trials >= 0, 'maximum trial exceed'
            max_trials -= 1
        mask = nib.Nifti1Image(np.zeros(shape).T, affine)
        c = crop(c, getIntersection(c, mask, strict=3), \
                pad=(8,1,8), ratio=(8,1,8))
        s = crop(s, getIntersection(s, mask, strict=3), \
                pad=(1,8,8), ratio=(1,8,8))
        a = crop(a, getIntersection(a, mask, strict=3), \
                pad=(8,8,1), ratio=(8,8,1))
        #print(s.shape, c.shape, a.shape)
        allgrids = affine2Grids(affine, shape, ref, a, s, c)
        #allgrids = randomPatchGrids( \
        #        ref, a, s, c, spacing=spacing, shape=shape)
        grids, invgrids = list( \
                zip(*[map(torch.Tensor, allgrids[i]) for i in (1,2,3)]))
        # normalize images
        images = [img.get_fdata().T for img in (a, s, c)]
        if np.issubdtype(a.get_data_dtype(), np.integer):
            images = [img+np.random.rand(*(img.shape)) for img in images]
        # maybe clip here?
        images = [torch.Tensor((image-minVal)/(maxVal-minVal)) \
                for image in images]
        # R(2)<->Sagittal, A(1)<->Coronal, S(0)<->Axial
        axes = [0, 2, 1]
        if gt is not None:
            # process gt
            gt = gt.get_fdata().T
            gt = torch.nn.functional.grid_sample( \
                    torch.Tensor(gt).unsqueeze(0).unsqueeze(0), \
                    torch.Tensor(allgrids[0][0]).unsqueeze(0))
            gt = (gt-minVal)/(maxVal-minVal)
        return gt, images, grids, invgrids, axes

    def __len__(self):
        return len(self.images)

    def name(self):
        return 'PatchDataset'


"""
def prepare3to2(image):
    data = image.get_data()
    affine = image.affine.copy()
    shape = data.shape
    axesXY = [0,1,2]
    axesZ = axesXY.pop(shape.index(min(shape)))
    data = np.moveaxis(data, axesZ, 2)
    affine = affine[:,axesXY+[axesZ]+[3]]
    return nib.Nifti1Image(data, affine)
"""
