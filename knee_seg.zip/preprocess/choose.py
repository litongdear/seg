import  os
import numpy as np
import shutil
base_dir = 'E:\\KneeImages\\BeiYiSan\\'
cp_path = 'D:\knee\\iso\\'

n = 0
copy_list = []
for dir in ['GaoLiXiang','Previous', 'sxw']:
    if os.path.isdir(os.path.join(base_dir, dir)):
        for subdir in os.listdir(os.path.join(base_dir, dir)):
            if os.path.isdir(os.path.join(base_dir, dir, subdir)):
                for sdir in os.listdir(os.path.join(base_dir, dir, subdir, 'SDY00000')):

                    ssdir = os.path.join(base_dir, dir, subdir, 'SDY00000', sdir)
                    if os.path.isdir(ssdir):
                        if not os.path.isdir(os.path.join(ssdir, os.listdir(ssdir)[0])):
                            file_num = len(os.listdir(ssdir))
                            if file_num >150:
                                n = n +1
                                print(file_num, os.path.join(base_dir, dir, subdir, 'SDY00000', sdir))
                                if os.path.join(base_dir, dir, subdir) not in copy_list:

                                    copy_list.append(os.path.join(base_dir, dir, subdir))
                                    shutil.copytree(os.path.join(base_dir, dir, subdir),
                                                             os.path.join(cp_path, dir, subdir))

                        # else:
                        #     for sssdir in os.listdir(ssdir):
                        #         file_num = len(os.listdir(os.path.join(ssdir, sssdir)))
                        #         if file_num > 150:
                        #             n = n + 1
                        #         print(file_num, os.path.join(ssdir, sssdir))
                        #         if os.listdir(os.path.join(base_dir, dir, subdir)) not in copy_list:
                        #             print(os.path.join(base_dir, dir, subdir))
                        #             copy_list.append(os.listdir(os.path.join(base_dir, dir, subdir)))
                        #             shutil.copytree(os.path.join(base_dir, dir, subdir),
                        #                                      os.path.join(cp_path, dir, subdir))
print(n)

# for dir in ['LiJie', 'SunWenXing']:
#     bb_dir = 'E:\KneeImages\BeiYiSan\\rest'
#     if os.path.isdir(os.path.join(bb_dir, dir)):
#         for subdir in os.listdir(os.path.join(bb_dir, dir)):
#             if os.path.isdir(os.path.join(bb_dir, dir, subdir)):
#                 for sdir in os.listdir(os.path.join(bb_dir, dir, subdir, 'SDY00000')):
#
#                     ssdir = os.path.join(bb_dir, dir, subdir, 'SDY00000', sdir)
#                     if os.path.isdir(ssdir):
#                         if not os.path.isdir(os.path.join(ssdir, os.listdir(ssdir)[0])):
#                             file_num = len(os.listdir(ssdir))
#                             if file_num >150:
#                                 n = n +1
#                                 print(file_num, os.path.join(bb_dir, dir, subdir, 'SDY00000', sdir))
#                         else:
#                             for sssdir in os.listdir(ssdir):
#                                 file_num = len(os.listdir(os.path.join(ssdir, sssdir)))
#                                 n = n + 1
#                                 print(file_num, os.path.join(ssdir, sssdir))
#                             print(' nnnnnnnn  ')