import os
import numpy as np
import SimpleITK as sitk

data_path = '/share/litong/knee/blur_seg/coronal_seg_data/'#'/share/litong/knee/blur_seg/seg_crop_down_10/'
save_path1 = '/share/litong/knee/blur_seg/coronal_seg_npy_train/'#'/share/litong/knee/blur_seg/seg_crop_npy_clear/'
save_path2 = '/share/litong/knee/blur_seg/coronal_seg_npy_test/'

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)
path_exist(save_path1)
path_exist(save_path2)

for num in os.listdir(data_path):
    # seg_file_path = os.path.join(data_path, num, num+'_new_seg_crop.nii.gz')
    # img_file_path = os.path.join(data_path, num, num+'_new_crop.nii.gz')

    # seg = sitk.ReadImage(seg_file_path)
    # img = sitk.ReadImage(img_file_path)
    # img_arr = sitk.GetArrayFromImage(img)
    # seg_arr = sitk.GetArrayFromImage(seg)
    # img_size = img.GetSize()

    # print(num, img_arr.shape, seg_arr.shape)
    # for i in range(img_size[0]):
    #     save_name = save_path1 + num+'_'+str(i)+'.npy'
    #     npy_arr = np.zeros((2, img_size[2], img_size[1],))
    #     print(npy_arr.shape)
    #     npy_arr[0, :, :] = img_arr[:, :, i]
    #     npy_arr[1, :, :] = seg_arr[:, :, i]
    #     np.save(save_name, npy_arr)

    img_file_path_crop = os.path.join(data_path, num, num + '_crop.nii.gz')
    img_crop = sitk.ReadImage(img_file_path_crop)
    img_arr_crop = sitk.GetArrayFromImage(img_crop)
    img_crop_size = img_crop.GetSize()
    for i in range(img_crop_size[0]):
        # seg_file_path = os.path.join(data_path, num, num+'_new_seg_crop.nii.gz')
        save_dir = os.path.join(save_path2, num)
        path_exist(save_dir)
        save_name = save_dir +'/'+ num + '_' + str(i) + '.npy'
        np.save(save_name, img_arr_crop[:, :, i])
