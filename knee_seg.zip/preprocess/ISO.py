import os
import SimpleITK as sitk
import numpy as np

img_path = 'D:\knee\iso_1\sxw\\1.2.528.1.1001.200.6033.2453.149885691930573.20190823043417462\SDY00000\S_PD_ISO'
save_psth = 'D:\knee\iso_mhd'
reader = sitk.ImageSeriesReader()
img_names = reader.GetGDCMSeriesFileNames(img_path)
reader.SetFileNames(img_names)
image = reader.Execute()
image.SetSpacing([0.8, 0.8 , 0.8])
save_name = os.path.join(save_psth, '043417462_s_pd_iso.mhd')
sitk.WriteImage(image, save_name)

