import numpy as np
import os
import pickle
import torch
import torch.nn.functional as F
import torch.utils.data as data
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
import pdb
# from PIL import Image
from torch.autograd import Variable
import numpy as np
import SimpleITK as sitk
from skimage import  transform
# from transform import train_transform, train_crop_transform, \
#     test_transform, test_crop5_transform, test_crop10_transform

class image_dataset(Dataset):
    def __init__(self, path, context_num):
        self.path = path
        self.context_num = context_num
        self.segList = []
        self.dir1 = 'test_seg/'
        self.dir2 = 'test_data_all'
        for line in os.listdir(os.path.join(path, self.dir1)):
            self.segList.append(line)
            # num = int(line.split('.')[0].split('_')[1])
            # if num < max_num and num >0:
            #     self.imageList.append(line)

    def read_npy(self, dir_num, index, context_num):
        start_flag = True
        for i in range(index-context_num//2, index+context_num//2+1):
            img_path = os.path.join(self.path, self.dir2, dir_num, dir_num + '_' + str(index - 1) + '.npy')
            img_tmp_arr = np.expand_dims(np.load(img_path), axis=0)
            if start_flag:
                img_arr = img_tmp_arr
                start_flag =False
            else:
                img_arr = np.concatenate((img_arr, img_tmp_arr), axis=0)
        return img_arr

    def __getitem__(self, item):
        seg_file = self.segList[item]
        dir_num, index = seg_file.split('_')[0], int(seg_file.split('_')[1])
        seg_path = os.path.join(self.path, self.dir1, seg_file)
        seg_arr = np.load(seg_path)
        img_arr = self.read_npy(dir_num, index, self.context_num)

        img_arr = (img_arr-np.min(img_arr))/(np.max(img_arr)-np.min(np.min(img_arr)))

        # a_tensor = torch.Tensor(np.expand_dims(a_arr0, axis=0))
        img_tensot = torch.Tensor(img_arr)
        sa_tensor = torch.Tensor(np.expand_dims(seg_arr, axis=0))
        # print(filePath, a_tensor.max(), sa_tensor.max())
        return img_tensot, sa_tensor, torch.Tensor([img_tensot.min()]).reshape([]), \
                torch.Tensor([img_tensot.max()]).reshape([])

    def __len__(self):
        return len(self.segList)

class image_dataset_test(Dataset):
    def __init__(self, path, context_num):
        self.path = path
        self.context_num = context_num
        self.imgList = []

        file_num = len(os.listdir(self.path))
        self.dir_num = self.path.split('/')[-1]
        for i in range(context_num//2, file_num-context_num//2):
            self.imgList.append(self.dir_num+'_'+str(i)+'.npy')

    def read_npy(self, dir_num, index, context_num):
        start_flag = True
        # print(index)
        for i in range(index-context_num//2, index+context_num//2+1):
            img_path = os.path.join(self.path, dir_num + '_' + str(i) + '.npy')
            # print(img_path)
            img_tmp_arr = np.expand_dims(np.load(img_path), axis=0)
            if start_flag:
                img_arr = img_tmp_arr
                start_flag =False
            else:
                img_arr = np.concatenate((img_arr, img_tmp_arr), axis=0)
        return img_arr

    def __getitem__(self, item):
        img_file = self.imgList[item]
        # print(img_file)
        index = int(img_file.split('.')[0].split('_')[1])
        img_arr = self.read_npy(self.dir_num, index, self.context_num)
        img_arr = (img_arr-np.min(img_arr))/(np.max(img_arr)-np.min(np.min(img_arr)))
        img_tensot = torch.Tensor(img_arr)
        sa_tensor = torch.Tensor(np.expand_dims(np.zeros((img_arr.shape[1], img_arr.shape[2])), axis=0))
        return img_tensot, sa_tensor, torch.Tensor([img_tensot.min()]).reshape([]), \
                torch.Tensor([img_tensot.max()]).reshape([])

    def __len__(self):
        return len(self.imgList)

def triple_load_data(data_dir, batch_size, context_num, shuffle=True):
    valid_dataset = image_dataset(data_dir, context_num)
    valid_loader = data.DataLoader(valid_dataset, batch_size=batch_size,
                                   num_workers=8, shuffle=shuffle)
    return  valid_loader

def triple_load_data_test(data_dir, batch_size, context_num, shuffle=True):
    valid_dataset = image_dataset_test(data_dir, context_num)
    valid_loader = data.DataLoader(valid_dataset, batch_size=batch_size,
                                   num_workers=8, shuffle=shuffle)
    return  valid_loader

def load_data_down(data_dir,):
    valid_dataset = image_dataset_down(data_dir)
    valid_loader = data.DataLoader(valid_dataset, batch_size=6,
                                   num_workers=8, shuffle=True)
    return  valid_loader

class image_dataset_down(Dataset):
    def __init__(self, path):
        self.path = path
        self.imageList = [line for line in os.listdir(path)]
        # self.transforms = transformfile

    def __getitem__(self, item):
        filePath = self.imageList[item]
        data0 = np.load(os.path.join(self.path, filePath))

        sa_arr0 = data0[1]
        a_arr0 = sa_arr0[:,::11]

        a_tensor = torch.Tensor(np.expand_dims(a_arr0, axis=0))
        sa_tensor = torch.Tensor(np.expand_dims(sa_arr0, axis=0))
        # print(a_tensor.shape, sa_tensor.shape)
        return a_tensor, sa_tensor, torch.Tensor([a_tensor.min()]).reshape([]), \
               torch.Tensor([a_tensor.max()]).reshape([])

    def __len__(self):
        return len(self.imageList)

def load_data_eval(data_dir,):
    valid_dataset = image_dataset(data_dir)
    valid_loader = data.DataLoader(valid_dataset, batch_size=32,
                                   num_workers=8, shuffle=True)
    return  valid_loader

def tensor2im(input_image, imtype=np.uint8):
    if isinstance(input_image, torch.Tensor):
        image_tensor = input_image.data
    else:
        return input_image
    image_numpy = image_tensor[0].cpu().float().numpy()
    if image_numpy.shape[0] == 1:
        image_numpy = np.tile(image_numpy, (3, 1, 1))
    image_numpy = np.transpose(image_numpy, (1, 2, 0)) * 256.0 - 0.5
    image_numpy = np.clip(image_numpy, 0, 255)
    return image_numpy.astype(imtype)
