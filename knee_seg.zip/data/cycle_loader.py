import numpy as np
import os
import pickle
import torch
import torch.nn.functional as F
import torch.utils.data as data
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
import pdb
# from PIL import Image
from torch.autograd import Variable
import numpy as np
import SimpleITK as sitk
from skimage import  transform
# from transform import train_transform, train_crop_transform, \
#     test_transform, test_crop5_transform, test_crop10_transform
import nibabel as nib
import random
import pandas as pd
from utils.nii_func import getVertices, getIntersectionMax, affine2Grids, getSpacing, inflate, affine2Grids_original

def align2RAS(image):
    # align (+x,+y,+z) to (R, A, S)
    eps = 1e-4
    data = image.get_data()
    affine = image.affine
    unitX, unitY, unitZ = list(map(lambda x: x/np.linalg.norm(x), \
            (affine[0:3,0], affine[0:3,1], affine[0:3,2])))
    # make sure it's square image
    assert  abs(unitX@unitY) < eps
    assert  abs(unitX@unitZ) < eps
    assert  abs(unitY@unitZ) < eps
    return nib.as_closest_canonical(image)

def randomOrigin_c(img, scale_factor, crop_size1, crop_size2):
    size = img.get_shape()
    size_y = (crop_size1-1) *scale_factor +1
    size_z = crop_size2
    range_y, range_z = size[1]-size_y, size[2]-size_z
    # print(range_y, range_z)
    random_y, random_z = random.randint(0, range_y-1), random.randint(0, range_z-1)
    return random_y, random_z

def randomOrigin_a(img, scale_factor, crop_size1, crop_size2):
    size = img.get_shape()
    size_z = (crop_size1-1) *scale_factor +1
    size_y = crop_size2
    range_y, range_z = size[1]-size_y, size[2]-size_z
    random_y, random_z = random.randint(0, range_y-1), random.randint(0, range_z-1)
    return random_y, random_z

def crop_a_func(img, crop_size1, crop_size2, crop_size3, sample=None):
    size = img.get_shape()
    data = img.get_fdata()
    size_x = crop_size3
    size_z = crop_size1
    size_y = crop_size2
    range_x, range_y, range_z = size[0]-size_x, size[1] - size_y, size[2] - size_z
    if range_x > 50:
        range_x_start = size[0]//2-size_x//2-20
        range_x_end = size[0]//2-size_x//2+20
    else:
        range_x_start = 10
        range_x_end = range_x-1

    if range_y > 50:
        range_y_start = size[1]//2-size_y//2-20
        range_y_end = size[1]//2-size_y//2+20
    else:
        range_y_start = 10
        range_y_end = range_x-1
    if not sample:
        random_x, random_y, random_z = random.randint(range_x_start, range_x_end), \
                                      random.randint(range_y_start, range_y_end), \
                                      random.randint(0, range_z - 1)
        data_crop = data[random_x:(random_x + crop_size3),
                      random_y:(random_y + crop_size2),
                      random_z:(random_z + crop_size1)]
        mask = np.zeros(data.shape)
        mask[random_x:(random_x + crop_size3),
                      random_y:(random_y + crop_size2),
                      random_z:(random_z + crop_size1)] = 1

        origin_index = np.array([random_x, random_y, random_z])

        affine = np.eye(4)
        affine[0:3, 3] += origin_index
        affine[:, 0:3] *= 1
        # red =img.affine
        affineRef = img.affine @ affine
        a_crop_nii = nib.Nifti1Image(data_crop, affineRef)
    # else:
    #     random_y, random_z = random.randint(0, range_y - 1), \
    #                          random.randint(0, range_z - 1)
    #     size = [i for i in range(size[0])]
    #     random.shuffle(size)
    #     data_crop = data[size[:sample],
    #                 random_y:(random_y + crop_size2),
    #                 random_z:(random_z + crop_size1)]
    #     mask = np.zeros(data.shape)
    #     mask[size[:sample],
    #     random_y:(random_y + crop_size2),
    #     random_z:(random_z + crop_size1)] = 1
    return data_crop,a_crop_nii, mask,

def crop_c_func(img, crop_size1, crop_size2, crop_size3, sample=None):
    size = img.get_shape()
    c_data = img.get_fdata()
    size_x = crop_size3
    size_y = crop_size1
    size_z = crop_size2
    range_x, range_y, range_z = size[0]-size_x, size[1]-size_y, size[2]-size_z
    if range_x > 60:
        range_x_start = size[0]//2-size_x//2-20
        range_x_end = size[0]//2-size_x//2+20
    else:
        range_x_start = 10
        range_x_end = range_x-1

    if range_z > 50:
        range_z_start = size[2]//2-size_z//2-20
        range_z_end = size[2]//2-size_z//2+20
    else:
        range_z_start = 10
        range_z_end = range_x-1
    # print(range_y, range_z)
    if not sample:
        random_x, random_y, random_z = random.randint(range_x_start, range_x_end),\
                                      random.randint(0, range_y-1), \
                                      random.randint(range_z_start, range_z_end)
        c_data_crop = c_data[random_x:(random_x + crop_size3),
                      random_y:(random_y + crop_size1),
                      random_z:(random_z + crop_size2)]
        mask = np.ones(c_data_crop.shape)
        # mask[random_x:(random_x + crop_size3),
        #               random_y:(random_y + crop_size1),
        #               random_z:(random_z + crop_size2)]=1
        origin_index = np.array([random_x, random_y, random_z])

        affine = np.eye(4)
        affine[0:3, 3] += origin_index
        affine[:, 0:3] *= 1
        # red =img.affine
        affineRef = img.affine @ affine
        c_crop_nii = nib.Nifti1Image(c_data_crop, affineRef)
        # basegrid = list(np.where(mask == 1))
        # basegrid.append(np.ones_like(basegrid[0]))
        # basegrid = np.stack(basegrid).reshape(4, crop_size3, crop_size1, crop_size2)
    # else:
    #     random_y, random_z = random.randint(0, range_y - 1), \
    #                          random.randint(0, range_z - 1)
    #     size = [i for i in range(size[0])]
    #     random.shuffle(size)
    #     c_data_crop = c_data[size[:sample],
    #                   random_y:(random_y + crop_size1),
    #                 random_z:(random_z + crop_size2)]
    #
    #     mask = np.zeros(c_data.shape)
    #     mask[size[:sample],
    #     random_y:(random_y + crop_size1),
    #     random_z:(random_z + crop_size2)] = 1
        # basegrid = list(np.where(mask == 1))
        # basegrid.append(np.ones_like(basegrid[0]))
        # basegrid = (np.stack(basegrid)).reshape(4, sample, crop_size1, crop_size2)

    return c_data_crop,c_crop_nii, mask,

def affine_func(img, origin):
    affine = np.eye(4)
    affine[0:3, 3] += origin
    affineRef = img.affine@affine
    return affineRef

def ger_origin_index_1(img1, img2, img3):
    affine = np.array(img1.affine)
    # inv_affine = np.linalg.inv(affine)
    origin = getIntersectionMax(img1, img2, img3, strict=3)
    range =origin[:, 1] - origin[:, 0]

    affineRef = affine_func(img1, origin[:, 0])
    shape = [448]*3
    grid = []
    # grid_1 = affine2Grids(affine, , img1)
    grid_2 = affine2Grids_original(affineRef, shape, img2)
    grid_3 = affine2Grids_original(affineRef, shape, img3)
    # grid.append(grid_1)
    grid.append(grid_2)
    grid.append(grid_3)
    return grid

def ger_origin_index(img1, img2):
    affine = np.array(img1.affine)
    grid_2 = affine2Grids_original(affine, img1.get_shape(), img2)
    return grid_2

class image_dataset(Dataset):
    def __init__(self, csv_path, raw_dir, view):
        self.images = []
        df = pd.read_csv(csv_path)
        self.view = view
        self.images += [str(line).zfill(5) for line in list(df['train'].values)]
        self.raw_path = raw_dir
        self.blurSize_min = 18
        self.blurSize_max = 224
        self.scale_factor = 13
        self.whole_size = 221
        self.slice_num = 200

    def __getitem__(self, index):
        # print(self.images[index])
        a, s, c, seg = [align2RAS(nib.load(
            os.path.join(self.raw_path, self.images[index],
                         self.images[index] + '_' + pos + '.nii.gz')))
            for pos in ['axial', 'sagittal_sp', 'coronal', 'seg_sp']]

        seg_data = seg.get_data()

        # crop into fixed size
        a_data_crop, a_crop_img, a_mask = crop_a_func(a, self.blurSize_min,
                                                   self.blurSize_max, self.slice_num, sample=None)
        c_data_crop, c_crop_img, c_mask = crop_c_func(c, self.blurSize_min,
                                          self.blurSize_max, self.slice_num, sample=None)
        # nib.save(c_crop_img, self.images[index]+'_crop.nii.gz')
        # a --> s
        if self.view == 'axial':
            axis = 0
            grid = ger_origin_index(s, a_crop_img)
            # inflate_a = inflate(torch.Tensor(a_mask.T), 15, 0)
            # a_mask_crop = torch.nn.functional.grid_sample(inflate_a.unsqueeze(0).unsqueeze(0),
            #                                               (torch.Tensor(grid_a[0][0])).unsqueeze(0), mode='nearest')
            a_crop_tensor = torch.Tensor(a_data_crop)
            a_minval, a_maxVal = torch.min(a_crop_tensor), torch.max(a_crop_tensor)
            crop_tensor = (a_crop_tensor - a_minval) / (a_maxVal - a_minval)
            mask_tensor = torch.Tensor(a_mask)

        # c --> s
        elif self.view == 'coronal':
            axis=1
            grid = ger_origin_index(s, c_crop_img)
            # inflate_c = inflate(torch.Tensor(c_mask.T), 15, 0)
            # c_mask_crop = torch.nn.functional.grid_sample(inflate_c.unsqueeze(0).unsqueeze(0),
            #                                               (torch.Tensor(grid_c[0][0])).unsqueeze(0), mode='nearest')
            c_crop_tensor = torch.Tensor(c_data_crop)
            c_minval, c_maxVal = torch.min(c_crop_tensor), torch.max(c_crop_tensor)
            crop_tensor = (c_crop_tensor - c_minval) / (c_maxVal - c_minval)
            mask_tensor = torch.Tensor(c_mask)

        else:
            raise ValueError('invalid view value')


        seg_tensor = torch.Tensor(seg_data)
        return crop_tensor, mask_tensor, seg_tensor, torch.Tensor(grid[0][0]), axis

    def __len__(self):
        return len(self.images)

def load_data_cycle(csv_path, raw_path, view, batch_size, shuffle=True):
    valid_dataset = image_dataset(csv_path, raw_path,view)
    valid_loader = data.DataLoader(valid_dataset, batch_size=batch_size,
                                   num_workers=8, shuffle=shuffle)
    return  valid_loader


def tensor2im(input_image, imtype=np.uint8):
    if isinstance(input_image, torch.Tensor):
        image_tensor = input_image.data
    else:
        return input_image
    image_numpy = image_tensor[0].cpu().float().numpy()
    if image_numpy.shape[0] == 1:
        image_numpy = np.tile(image_numpy, (3, 1, 1))
    image_numpy = np.transpose(image_numpy, (1, 2, 0)) * 256.0 - 0.5
    image_numpy = np.clip(image_numpy, 0, 255)
    return image_numpy.astype(imtype)
