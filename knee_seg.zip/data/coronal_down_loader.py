import numpy as np
import os
import pickle
import torch
import torch.nn.functional as F
import torch.utils.data as data
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
import pdb
from PIL import Image
from torch.autograd import Variable
import numpy as np
import SimpleITK as sitk
from skimage import  transform
# from transform import train_transform, train_crop_transform, \
#     test_transform, test_crop5_transform, test_crop10_transform
import nibabel as nib
import random
import pandas as pd
from utils import nii_func

def align2RAS(image):
    # align (+x,+y,+z) to (R, A, S)
    eps = 1e-4
    data = image.get_data()
    affine = image.affine
    unitX, unitY, unitZ = list(map(lambda x: x/np.linalg.norm(x), \
            (affine[0:3,0], affine[0:3,1], affine[0:3,2])))
    # make sure it's square image
    assert  abs(unitX@unitY) < eps
    assert  abs(unitX@unitZ) < eps
    assert  abs(unitY@unitZ) < eps
    return nib.as_closest_canonical(image)

class image_dataset(Dataset):
    def __init__(self, args, csv_path, raw_dir, view):
        self.images = []
        df = pd.read_csv(csv_path)
        self.view = view
        self.images += [str(line).zfill(5) for line in list(df['train'].values)]
        self.raw_path = raw_dir
        self.blurSize_x = 222
        self.blurSize_min = 18
        self.blurSize_max = 222
        self.scale_factor = 13
        self.whole_size = 222
        self.coronal_seg_dir = args.coronal_segdir
            #'/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_coronal_6/'
        self.axial_seg_dir = args.axial_segdir
        #'/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_axial_6/'
        if self.view == 'axial':
            self.crop_size = (self.blurSize_max, self.whole_size + 1)
        elif self.view == 'coronal':
            self.crop_size = (self.whole_size + 1, self.blurSize_max)

    def grid_sample(self, a, c):
        grid = nii_func.affine2Grids_original(c.affine, c.shape, a)
        # coronal_mask_tensor = torch.Tensor(c.get_data().T)
        axial_mask_tensor = torch.Tensor(a.get_data().T)

        a_grid = torch.Tensor(grid[0][0])
        a_mask = torch.nn.functional.grid_sample(axial_mask_tensor.unsqueeze(0).unsqueeze(0),
                                                 a_grid.unsqueeze(0), mode='nearest')

        a_mask_arr = a_mask.squeeze().data.numpy().T.astype(np.float)
        return a_mask_arr

    def __getitem__(self, index):
        # print(self.images[index])

        # a_seg_data = self.grid_sample(a_seg, c_seg)

        if self.view == 'axial':
            c = nib.load(os.path.join(self.raw_path, self.images[index],
                                      self.images[index] + '_' + 'axial' + '.nii.gz'))
            c_seg = nib.load(os.path.join(self.axial_seg_dir, 'seg_mask_ep106',
                                          self.images[index] + '_' + 'axial_mask' + '.nii.gz'))
            # a_seg = nib.load(os.path.join(self.axial_seg_dir, 'seg_mask',
            #                               self.images[index] + '_' + 'axial_mask' + '.nii.gz'))

            img_data = c.get_fdata()
            img_shape = c.get_shape()
            c_seg_data = c_seg.get_data()
            random_x, random_y, random_z = random.randint(0, img_data.shape[0] - self.blurSize_x), \
                                           random.randint(0, img_data.shape[1] - self.blurSize_max), \
                                           random.randint(0, img_data.shape[2] - self.blurSize_min)
            img_crop = img_data[random_x:random_x + self.blurSize_x,
                       random_y:random_y + self.blurSize_max,
                       random_z:random_z + self.blurSize_min]
            # img_arr = np.zeros((img_crop.shape[0], (img_crop.shape[1] - 1) * self.scale_factor + 1,
            #                     img_crop.shape[2]))
            # img_arr[:, :, ::13] = img_crop
            img_arr = (img_crop - np.min(img_crop)) / (np.max(img_crop) - np.min(np.min(img_crop)))

            c_seg_crop = c_seg_data[random_x:random_x + self.blurSize_x,
                                    random_y:random_y + self.blurSize_max,
                                    random_z:random_z + self.blurSize_min]
            # a_seg_crop = a_seg_data[random_x:random_x + self.blurSize_x+1,
            #                         random_y:random_y + self.blurSize_max+1,
            #                         random_z:random_z + self.blurSize_max+1]

        elif self.view == 'coronal':
            c = nib.load(os.path.join(self.raw_path, self.images[index],
                                      self.images[index] + '_' + 'coronal' + '.nii.gz'))
            c_seg = nib.load(os.path.join(self.coronal_seg_dir, 'seg_mask_ep10',
                                          self.images[index] + '_' + 'coronal_mask' + '.nii.gz'))
            # a_seg = nib.load(os.path.join(self.axial_seg_dir, 'seg_mask',
            #                               self.images[index] + '_' + 'axial_mask' + '.nii.gz'))

            img_data = c.get_fdata()
            img_shape = c.get_shape()
            c_seg_data = c_seg.get_data()
            random_x, random_y, random_z = random.randint(0, img_data.shape[0] - self.blurSize_x), \
                                           random.randint(0, img_data.shape[1] - self.blurSize_min), \
                                           random.randint(0, img_data.shape[2] - self.blurSize_max)
            img_crop = img_data[random_x:random_x + self.blurSize_x,
                                random_y:random_y + self.blurSize_min,
                                random_z:random_z + self.blurSize_max]
            # img_arr = np.zeros((img_crop.shape[0], (img_crop.shape[1] - 1) * self.scale_factor + 1,
            #                     img_crop.shape[2]))
            # img_arr[:, ::13, :] = img_crop
            img_arr = (img_crop - np.min(img_crop)) / (np.max(img_crop) - np.min(np.min(img_crop)))
            c_seg_crop = c_seg_data[random_x:random_x + self.blurSize_x,
                                    (random_y):(random_y + self.blurSize_min),
                                    random_z:random_z + self.blurSize_max]

            # a_seg_crop = a_seg_data[random_x:random_x + self.blurSize_x,
            #                         ::self.scale_factor,
            #                         # random_y:random_y + self.blurSize_max,
            #                         random_z:random_z + self.blurSize_max]
        else:
            raise ValueError('wrong view str')

        crop_tensor = torch.Tensor(img_arr)
        c_seg_tensor = torch.Tensor(c_seg_crop)
        # a_seg_tensor = torch.Tensor(a_seg_crop)
        # print(crop_tensor.shape, c_seg_tensor.shape)
        return crop_tensor, c_seg_tensor

    def __len__(self):
        return len(self.images)

class image_dataset_sagittal_test(Dataset):
    def __init__(self, args, csv_path, raw_dir, view):
        self.images = []
        df = pd.read_csv(csv_path)
        self.view = view
        self.images += [str(line).zfill(5) for line in list(df['test'].values)]
        self.raw_path = raw_dir
        self.blurSize_x = 222
        self.blurSize_min = 18
        self.blurSize_max = 222
        self.scale_factor = 13
        self.whole_size = 222
        self.coronal_seg_dir = args.coronal_segdir
            #'/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_coronal_6/'
        self.axial_seg_dir = args.axial_segdir
        #'/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_axial_6/'
        if self.view == 'axial':
            self.crop_size = (self.blurSize_max, self.whole_size + 1)
        elif self.view == 'coronal':
            self.crop_size = (self.whole_size + 1, self.blurSize_max)

    def grid_sample(self, a, c):
        grid = nii_func.affine2Grids_original(c.affine, c.shape, a)
        # coronal_mask_tensor = torch.Tensor(c.get_data().T)
        axial_mask_tensor = torch.Tensor(a.get_data().T)

        a_grid = torch.Tensor(grid[0][0])
        a_mask = torch.nn.functional.grid_sample(axial_mask_tensor.unsqueeze(0).unsqueeze(0),
                                                 a_grid.unsqueeze(0), mode='nearest')

        a_mask_arr = a_mask.squeeze().data.numpy().T.astype(np.float)
        return a_mask_arr

    def __getitem__(self, index):
        # print(self.images[index])
        c = nib.load(os.path.join(self.raw_path, self.images[index],
                         self.images[index] + '_' + 'coronal' + '.nii.gz'))
        c_seg = nib.load(os.path.join(self.coronal_seg_dir, 'seg_mask',
                                      self.images[index] + '_' + 'coronal_mask' + '.nii.gz'))
        a_seg = nib.load(os.path.join(self.axial_seg_dir, 'seg_mask',
                                      self.images[index] + '_' + 'axial_mask' + '.nii.gz'))

        img_data = c.get_fdata()
        img_shape = c.get_shape()
        c_seg_data = c_seg.get_data()
        # a_seg_data = self.grid_sample(a_seg, c_seg)

        if self.view == 'axial':
            random_x, random_y, random_z = random.randint(0, img_data.shape[0] - self.blurSize_x), \
                                           random.randint(0, img_data.shape[1] - self.blurSize_max), \
                                           random.randint(0, img_data.shape[2] - self.blurSize_min)
            img_crop = img_data[random_x:random_x + self.blurSize_x + 1,
                       random_y:random_y + self.blurSize_max + 1,
                       random_z:random_z + self.blurSize_min + 1]
            img_arr = np.zeros((img_crop.shape[0], (img_crop.shape[1] - 1) * self.scale_factor + 1,
                                img_crop.shape[2]))
            img_arr[:, :, ::13] = img_crop
            img_arr = (img_arr - np.min(img_arr)) / (np.max(img_arr) - np.min(np.min(img_arr)))

            c_seg_crop = c_seg_data[random_x:random_x + self.blurSize_x+1,
                                    random_y:random_y + self.blurSize_max+1,
                                    random_z:random_z + self.blurSize_max+1]
            a_seg_crop = a_seg_data[random_x:random_x + self.blurSize_x+1,
                                    random_y:random_y + self.blurSize_max+1,
                                    random_z:random_z + self.blurSize_max+1]

        elif self.view == 'coronal':
            img_crop = img_data
            img_arr = (img_crop - np.min(img_crop)) / (np.max(img_crop) - np.min(np.min(img_crop)))
            c_seg_crop = c_seg_data

            # a_seg_crop = a_seg_data[random_x:random_x + self.blurSize_x,
            #                         ::self.scale_factor,
            #                         # random_y:random_y + self.blurSize_max,
            #                         random_z:random_z + self.blurSize_max]
        else:
            raise ValueError('wrong view str')

        crop_tensor = torch.Tensor(img_arr)
        c_seg_tensor = torch.Tensor(c_seg_crop)

        return crop_tensor, c_seg_tensor, self.images[index]

    def __len__(self):
        return len(self.images)

def load_data_lowHigh(args, csv_path, raw_path, view, batch_size, shuffle=True):
    valid_dataset = image_dataset(args, csv_path, raw_path, view)
    valid_loader = data.DataLoader(valid_dataset, batch_size=batch_size,
                                   num_workers=8, shuffle=shuffle)
    return  valid_loader

def load_data_lowHigh_sagittal_test(args, csv_path, raw_path, view, batch_size, shuffle=True):
    valid_dataset = image_dataset_sagittal_test(args, csv_path, raw_path,view)
    valid_loader = data.DataLoader(valid_dataset, batch_size=1,
                                   num_workers=8, shuffle=False)
    return  valid_loader


def tensor2im(input_image, imtype=np.uint8):
    if isinstance(input_image, torch.Tensor):
        image_tensor = input_image.data
    else:
        return input_image
    image_numpy = image_tensor[0].cpu().float().numpy()
    if image_numpy.shape[0] == 1:
        image_numpy = np.tile(image_numpy, (3, 1, 1))
    image_numpy = np.transpose(image_numpy, (1, 2, 0)) * 256.0 - 0.5
    image_numpy = np.clip(image_numpy, 0, 255)
    return image_numpy.astype(imtype)
