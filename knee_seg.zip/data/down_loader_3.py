import numpy as np
import os
import pickle
import torch
import torch.nn.functional as F
import torch.utils.data as data
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
import pdb
from PIL import Image
from torch.autograd import Variable
import numpy as np
import SimpleITK as sitk
from utils import nii_func
from skimage import  transform
# from transform import train_transform, train_crop_transform, \
#     test_transform, test_crop5_transform, test_crop10_transform
import nibabel as nib
import random
import pandas as pd

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)
def align2RAS(image):
    # align (+x,+y,+z) to (R, A, S)
    eps = 1e-4
    data = image.get_data()
    affine = image.affine
    unitX, unitY, unitZ = list(map(lambda x: x/np.linalg.norm(x), \
            (affine[0:3,0], affine[0:3,1], affine[0:3,2])))
    # make sure it's square image
    assert  abs(unitX@unitY) < eps
    assert  abs(unitX@unitZ) < eps
    assert  abs(unitY@unitZ) < eps
    return nib.as_closest_canonical(image)

def randomOrigin_c(size, scale_factor, crop_size1, crop_size2):
    # size = img.get_shape()
    size_y = (crop_size1-1) *scale_factor +1
    size_z = crop_size2
    range_y, range_z = size[1]-size_y, size[2]-size_z
    # print(range_y, range_z)
    random_y, random_z = random.randint(0, range_y-1), random.randint(0, range_z-1)
    return random_y, random_z

def randomOrigin_a(size, scale_factor, crop_size1, crop_size2):
    # size = img.get_shape()
    size_z = (crop_size1-1) *scale_factor +1
    size_y = crop_size2
    range_y, range_z = size[1]-size_y, size[2]-size_z
    random_y, random_z = random.randint(0, range_y-1), random.randint(0, range_z-1)
    return random_y, random_z

class image_dataset(Dataset):
    def __init__(self, args, csv_path, raw_dir, view):
        self.images = []
        # for t in os.listdir(raw_dir):
        #     if t.endswith('.npy'):
        #         self.images.append(t)

        df = pd.read_csv(csv_path)
        self.view = view
        self.images += [str(line).zfill(5) for line in list(df['train'].values)]
        self.raw_path = raw_dir
        self.blurSize_min = 18
        self.blurSize_max = 222
        self.scale_factor = 13
        self.whole_size = 221
        if self.view == 'axial':
            self.crop_size = (self.blurSize_max, self.whole_size+1)
        elif self.view =='coronal':
            self.crop_size = (self.whole_size + 1, self.blurSize_max)
        self.coronal_seg_dir = args.coronal_segdir
        # '/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_coronal_6/'
        self.axial_seg_dir = args.axial_segdir
        self.seg_path = '/share/litong/knee/spacing_seg_nii/'

    def down_s_a(self, s_data, s_seg):
        a_y, a_z = randomOrigin_a(s_data.shape, self.scale_factor, self.blurSize_min, self.blurSize_max)
        crop_arr = s_data[:, a_y:(a_y + self.blurSize_max),
                   a_z:(a_z + self.whole_size + 1):self.scale_factor]
        crop_seg = s_seg[:, a_y:(a_y + self.blurSize_max),
                   a_z:(a_z + self.whole_size + 1):self.scale_factor]
        crop = (crop_arr - np.min(crop_arr)) / (np.max(crop_arr) - np.min(crop_arr))
        return crop, crop_seg

    def down_s_c(self, s_data, s_seg):
        c_y, c_z = randomOrigin_c(s_data.shape, self.scale_factor, self.blurSize_min, self.blurSize_max)
        crop_arr = s_data[:, c_y:(c_y + self.whole_size + 1):self.scale_factor,
                   c_z:(c_z + self.blurSize_max)]
        crop_seg = s_seg[:,c_y:(c_y + self.whole_size + 1):self.scale_factor,
                   c_z:(c_z + self.blurSize_max)]
        crop = (crop_arr - np.min(crop_arr)) / (np.max(crop_arr) - np.min(crop_arr))
        return crop, crop_seg

    def grid_sample(self, s, image):
        # s_data = s.get_fdata()
        # s_affine = s.affine
        # s_shape = s.get_shape()

        grid = nii_func.affine2Grids_original(image.affine, image.shape, s)
        # coronal_mask_tensor = torch.Tensor(c.get_data().T)
        axial_mask_tensor = torch.Tensor(s.get_data().T)

        a_grid = torch.Tensor(grid[0][0])
        a_mask = torch.nn.functional.grid_sample(axial_mask_tensor.unsqueeze(0).unsqueeze(0),
                                                 a_grid.unsqueeze(0), mode='nearest')
        a_mask_arr = a_mask.squeeze().permute(2,1,0)
        return a_mask_arr

    def grid_sample_mask(self, s, image):
        # s_data = s.get_fdata()
        # s_affine = s.affine
        scale_factor = 13
        s_shape = s.get_shape()
        mask = torch.zeros(s_shape[0], s_shape[1], (s_shape[2] - 1) * scale_factor + 1)
        mask[:, :, ::self.scale_factor,] = 1

        grid = nii_func.affine2Grids_original(image.affine, image.shape, s)
        # coronal_mask_tensor = torch.Tensor(c.get_data().T)

        mask_tensor = mask.permute(2,1,0)

        a_grid = torch.Tensor(grid[0][0])
        print(mask.shape, a_grid.shape)
        a_mask = torch.nn.functional.grid_sample(mask_tensor.unsqueeze(0).unsqueeze(0),
                                                 a_grid.unsqueeze(0), mode='nearest')
        a_mask_arr = a_mask.squeeze().permute(2,1,0)
        return a_mask_arr

    def seg_num_change(self, seg):
        seg_data = seg.get_data()
        new_seg_data = seg_data.copy()
        new_seg_data[np.where(new_seg_data == 4)] = 3
        new_seg_data[np.where(new_seg_data == 5)] = 4
        new_seg_data[np.where(new_seg_data == 6)] = 5
        new_seg = nib.Nifti1Image(new_seg_data, seg.affine)
        return new_seg

    def __getitem__(self, index):
        # num = self.images[index]
        num = '00356'
        s = nib.load(os.path.join(self.raw_path, num,
                                  num + '_' + 'sagittal_sp' + '.nii.gz'))
        s_seg = nib.load(os.path.join(self.raw_path, num,
                                      num + '_' + 'seg_sp' + '.nii.gz'))
        s_data = s.get_fdata()
        s_seg_data = s_seg.get_data()

        s_seg_origin_old = nib.load(os.path.join(self.seg_path,
                                                 num + '_' + 'seg' + '.nii.gz'))
        s_seg_origin = self.seg_num_change(s_seg_origin_old)

        if self.view == 'axial':
            c = nib.load(os.path.join(self.raw_path, num,
                                      num + '_' + 'axial' + '.nii.gz'))
            c_seg = nib.load(os.path.join(self.axial_seg_dir, 'seg_mask',
                                          num + '_' + 'axial_mask' + '.nii.gz'))
            img_data = c.get_fdata()
            c_seg_data = c_seg.get_data()

            axial_seg = self.grid_sample(s_seg_origin, c)
            axial_seg_mask = self.grid_sample_mask(s_seg_origin, c)
            axail_slice_seg = axial_seg*axial_seg_mask

            # save_path = '/share/litong/knee/blur_seg/tmp/axial_origin_13_6'
            # path_exist(save_path)
            # save_name = os.path.join(save_path, self.images[index]+'_seg.nii.gz')
            # a_seg_img = nib.Nifti1Image(axial_seg.data.numpy(), c.affine)
            # nib.save(a_seg_img, save_name)
            # save_name = os.path.join(save_path, self.images[index] + '_seg_slice.nii.gz')
            # a_seg_img = nib.Nifti1Image(axail_slice_seg.data.numpy(), c.affine)
            # nib.save(a_seg_img, save_name)
            # save_name = os.path.join(save_path, self.images[index] + '.nii.gz')
            # nib.save(c, save_name)
            # print(axial_seg.shape, c_seg.shape, axial_seg_mask.shape)

            random_x, random_y, random_z = random.randint(0, img_data.shape[0] - self.blurSize_max), \
                                           random.randint(0, img_data.shape[1] - self.blurSize_max), \
                                           random.randint(0, img_data.shape[2] - self.blurSize_min)
            img_crop = img_data[random_x:random_x + self.blurSize_max,
                       random_y:random_y + self.blurSize_max,
                       random_z:random_z + self.blurSize_min]

            crop = (img_crop - np.min(img_crop)) / (np.max(img_crop) - np.min(np.min(img_crop)))

            crop_seg = c_seg_data[random_x:random_x + self.blurSize_max,
                         random_y:random_y + self.blurSize_max,
                         random_z:random_z + self.blurSize_min]
            s_crop, s_crop_seg = self.down_s_a(s_data, s_seg_data)
            print(s_crop.shape, s_crop_seg.shape)

        elif self.view == 'coronal':
            c = nib.load(os.path.join(self.raw_path, num,
                                      num + '_' + 'coronal' + '.nii.gz'))
            c_seg = nib.load(os.path.join(self.coronal_seg_dir, 'seg_mask',
                                          num + '_' + 'coronal_mask' + '.nii.gz'))
            img_data = c.get_fdata()
            c_seg_data = c_seg.get_data()

            axial_seg = self.grid_sample(s_seg_origin, c)
            axial_seg_mask = self.grid_sample_mask(s_seg_origin, c)
            axail_slice_seg = axial_seg * axial_seg_mask

            save_path = '/share/litong/knee/blur_seg/tmp/coronal_origin_13_6'
            path_exist(save_path)
            save_name = os.path.join(save_path, num + '_seg.nii.gz')
            a_seg_img = nib.Nifti1Image(axial_seg.data.numpy(), c.affine)
            nib.save(a_seg_img, save_name)
            save_name = os.path.join(save_path, num + '_seg_slice.nii.gz')
            a_seg_img = nib.Nifti1Image(axail_slice_seg.data.numpy(), c.affine)
            nib.save(a_seg_img, save_name)
            save_name = os.path.join(save_path, num + '.nii.gz')
            nib.save(c, save_name)

            random_x, random_y, random_z = random.randint(0, img_data.shape[0] - self.blurSize_max), \
                                           random.randint(0, img_data.shape[1] - self.blurSize_min), \
                                           random.randint(0, img_data.shape[2] - self.blurSize_max)

            img_crop = img_data[random_x:random_x + self.blurSize_max,
                                random_y:random_y + self.blurSize_min,
                                random_z:random_z + self.blurSize_max]

            crop = (img_crop - np.min(img_crop)) / (np.max(img_crop) - np.min(np.min(img_crop)))
            crop_seg = c_seg_data[random_x:random_x + self.blurSize_max,
                                    (random_y):(random_y + self.blurSize_min),
                                    random_z:random_z + self.blurSize_max]
            s_crop, s_crop_seg = self.down_s_c(s_data, s_seg_data)
            print(s_crop.shape, s_crop_seg.shape)

        else:
            raise ValueError('wrong view str')

        # crop = torch.unsqueeze(torch.Tensor(crop), 0)
        crop_tensor = torch.Tensor(crop)
        seg_tensor = torch.Tensor(crop_seg)

        size = [i for i in range(crop_tensor.shape[0])]
        random.shuffle(size)
        crop_tensor_sample = crop_tensor[size[:64]]
        seg_tensor_sample = seg_tensor[size[:64]]
        # print(self.images[index], crop_tensor_sample.shape, seg_tensor_sample.shape)
        return crop_tensor_sample, seg_tensor_sample

    def __len__(self):
        return len(self.images)

class image_dataset_sagittal_test(Dataset):
    def __init__(self, csv_path, raw_dir, view):
        self.images = []
        df = pd.read_csv(csv_path)
        self.view = view
        self.images += [str(line).zfill(5) for line in list(df['test'].values)]
        self.raw_path = raw_dir
        self.blurSize_min = 18
        self.blurSize_max = 224
        self.scale_factor = 13
        self.whole_size = 221
        if self.view == 'axial':
            self.crop_size = (self.blurSize_max, self.whole_size + 1)
        elif self.view == 'coronal':
            self.crop_size = (self.whole_size + 1, self.blurSize_max)

    def __getitem__(self, index):
        # print(self.images[index])
        s, seg = [nib.load(
            os.path.join(self.raw_path, self.images[index],
                         self.images[index] + '_' + pos + '.nii.gz'))
            for pos in ['sagittal_sp', 'seg_sp']]
        s_data = s.get_fdata()
        seg_data = seg.get_data()

        if self.view == 'axial':
            if s.get_shape()[2] > self.whole_size and s.get_shape()[1] > self.blurSize_max:

                crop_a = s_data[:, :, ::self.scale_factor]
                crop_seg = seg_data[:, :, ::self.scale_factor]
                crop = (crop_a - np.min(crop_a)) / (np.max(crop_a) - np.min(np.min(crop_a)))
            else:
                raise ValueError(self.images[index], s.shape, ' is too small')

        elif self.view == 'coronal':
            if s.get_shape()[1] > self.whole_size and s.get_shape()[2] > self.blurSize_max:
                crop_c = s_data[:, ::self.scale_factor, :]
                crop_seg = seg_data[:, ::self.scale_factor, :]
                crop = (crop_c - np.min(crop_c)) / (np.max(crop_c) - np.min(np.min(crop_c)))
            else:
                raise ValueError(self.images[index], s.shape, ' is too small')
            # crop_seg = np.zeros(crop.shape)
        elif self.view == 'sagittal':
            crop_s = s_data
            crop_seg = seg_data
            crop = (crop_s - np.min(crop_s)) / (np.max(crop_s) - np.min(np.min(crop_s)))
        else:
            raise ValueError('invalid view value')


        crop_seg[np.where(crop_seg == 4)] = 3
        crop_seg[np.where(crop_seg == 5)] = 4
        crop_seg[np.where(crop_seg == 6)] = 5
        crop_tensor = torch.Tensor(crop)
        seg_tensor = torch.Tensor(crop_seg)

        # size = [i for i in range(crop_tensor.shape[0])]
        # random.shuffle(size)
        # crop_tensor_sample = crop_tensor[size[:3]]
        # seg_tensor_sample = seg_tensor[size[:3]]
        # print(self.images[index], crop_tensor_sample.shape, seg_tensor_sample.shape)
        return crop_tensor, seg_tensor, self.images[index]

    def __len__(self):
        return len(self.images)


def load_data_lowHigh(args, csv_path, raw_path, view, batch_size, shuffle=True):
    valid_dataset = image_dataset(args, csv_path, raw_path,view)
    valid_loader = data.DataLoader(valid_dataset, batch_size=batch_size,
                                   num_workers=8, shuffle=shuffle)
    return  valid_loader

def load_data_lowHigh_sagittal_test(csv_path, raw_path, view, batch_size, shuffle=True):
    valid_dataset = image_dataset_sagittal_test(csv_path, raw_path,view)
    valid_loader = data.DataLoader(valid_dataset, batch_size=1,
                                   num_workers=8, shuffle=False)
    return  valid_loader


def tensor2im(input_image, imtype=np.uint8):
    if isinstance(input_image, torch.Tensor):
        image_tensor = input_image.data
    else:
        return input_image
    image_numpy = image_tensor[0].cpu().float().numpy()
    if image_numpy.shape[0] == 1:
        image_numpy = np.tile(image_numpy, (3, 1, 1))
    image_numpy = np.transpose(image_numpy, (1, 2, 0)) * 256.0 - 0.5
    image_numpy = np.clip(image_numpy, 0, 255)
    return image_numpy.astype(imtype)
