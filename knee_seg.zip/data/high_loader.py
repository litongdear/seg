import numpy as np
import os
import pickle
import torch
import torch.nn.functional as F
import torch.utils.data as data
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
import pdb
from PIL import Image
from torch.autograd import Variable
import numpy as np
import SimpleITK as sitk
from skimage import  transform
# from transform import train_transform, train_crop_transform, \
#     test_transform, test_crop5_transform, test_crop10_transform
import nibabel as nib
import random
import pandas as pd

def align2RAS(image):
    # align (+x,+y,+z) to (R, A, S)
    eps = 1e-4
    data = image.get_data()
    affine = image.affine
    unitX, unitY, unitZ = list(map(lambda x: x/np.linalg.norm(x), \
            (affine[0:3,0], affine[0:3,1], affine[0:3,2])))
    # make sure it's square image
    assert  abs(unitX@unitY) < eps
    assert  abs(unitX@unitZ) < eps
    assert  abs(unitY@unitZ) < eps
    return nib.as_closest_canonical(image)

def randomOrigin_c(size, scale_factor, crop_size1, crop_size2):
    # size = img.get_shape()
    size_y = (crop_size1-1) *scale_factor +1
    size_z = crop_size2
    range_y, range_z = size[0]-size_y, size[1]-size_z
    # print(range_y, range_z)
    random_y, random_z = random.randint(0, range_y-1), random.randint(0, range_z-1)
    return random_y, random_z

def randomOrigin_a(size, scale_factor, crop_size1, crop_size2):
    # size = img.get_shape()
    size_z = (crop_size1-1) *scale_factor +1
    size_y = crop_size2
    range_y, range_z = size[0]-size_y, size[1]-size_z
    random_y, random_z = random.randint(0, range_y-1), random.randint(0, range_z-1)
    return random_y, random_z

class image_dataset(Dataset):
    def __init__(self, csv_path, raw_dir, view):
        self.images = []
        for t in os.listdir(raw_dir):
            if t.endswith('.npy'):
                self.images.append(t)

        # df = pd.read_csv(csv_path)
        self.view = view
        # self.images += [str(line).zfill(5) for line in list(df['train'].values)]
        self.raw_path = raw_dir
        self.blurSize_min = 18
        self.blurSize_max = 222
        self.scale_factor = 13
        self.whole_size = 221
        if self.view == 'axial':
            self.crop_size = (self.blurSize_max, self.whole_size+1)
        elif self.view =='coronal':
            self.crop_size = (self.whole_size + 1, self.blurSize_max)


    def __getitem__(self, index):

        img_path = os.path.join(self.raw_path, self.images[index])
        arr = np.load(img_path)
        # print(arr.shape)
        s_data = arr[0, :, :]
        seg_data = arr[1, :, :]
        if self.view == 'axial':
            if s_data.shape[1] > self.whole_size and s_data.shape[0] > self.blurSize_max:
                a_y, a_z = randomOrigin_a(s_data.shape, self.scale_factor, self.blurSize_min, self.blurSize_max)
                crop_a = s_data[a_y:(a_y + self.blurSize_max), a_z:(a_z + self.whole_size+1)]

                # crop_a[a_y:(a_y + self.blurSize_max),
                #            a_z:(a_z + self.whole_size + 1):self.scale_factor]=0
                crop_arr = np.zeros(crop_a.shape)
                crop_arr[:, ::self.scale_factor] = crop_a[:, ::self.scale_factor]
                # crop_a_mask = np.zeros(crop_a.shape)
                # crop_a_mask[:, a_y:(a_y + self.blurSize_max),
                #            a_z:(a_z + self.whole_size + 1):self.scale_factor]=1
                crop_seg = seg_data[a_y:(a_y + self.blurSize_max), a_z:(a_z + self.whole_size+1)]
                crop = (crop_arr - np.min(crop_arr)) / (np.max(crop_arr) - np.min(crop_arr))
                crop_origin = (crop_a - np.min(crop_a)) / (np.max(crop_a) - np.min(crop_a))
            else:
                raise ValueError(self.images[index], s_data.shape, ' is too small')

        elif self.view == 'coronal':
            if s_data.shape[0]>self.whole_size and s_data.shape[1]>self.blurSize_max:
                c_y, c_z = randomOrigin_c(s_data.shape, self.scale_factor, self.blurSize_min, self.blurSize_max)
                crop_c = s_data[c_y:(c_y + self.whole_size+1), c_z:(c_z + self.blurSize_max)]
                crop_arr = np.zeros(crop_c.shape)
                crop_arr[::self.scale_factor,:] = crop_c[::self.scale_factor, :]
                # crop_c_mask = np.zeros(crop_c.shape)
                # crop_c_mask[:, c_y:(c_y + self.whole_size + 1):self.scale_factor,
                #                                   c_z:(c_z + self.blurSize_max)]=1
                crop_seg = seg_data[c_y:(c_y + self.whole_size+1), c_z:(c_z + self.blurSize_max)]
                crop = (crop_arr - np.min(crop_arr)) / (np.max(crop_arr) - np.min(crop_arr))
                crop_origin = (crop_c - np.min(crop_c)) / (np.max(crop_c) - np.min(crop_c))
            else:
                raise ValueError(self.images[index], s_data.shape, ' is too small')
            # crop_seg = np.zeros(crop.shape)
        elif self.view == 'sagittal':
            if s_data.shape[0]>self.whole_size and s_data.shape[1]>self.blurSize_max:
                c_y, c_z = randomOrigin_c(s_data.shape, self.scale_factor, self.blurSize_min, self.blurSize_max)
                crop_c = s_data[c_y:(c_y + self.whole_size+1), c_z:(c_z + self.blurSize_max)]

                # crop_c_mask = np.zeros(crop_c.shape)
                # crop_c_mask[:, c_y:(c_y + self.whole_size + 1):self.scale_factor,
                #                                   c_z:(c_z + self.blurSize_max)]=1
                crop_seg = seg_data[c_y:(c_y + self.whole_size+1), c_z:(c_z + self.blurSize_max)]
                del seg_data, s_data
                crop = (crop_c - np.min(crop_c)) / (np.max(crop_c) - np.min(np.min(crop_c)))
            else:
                raise ValueError(self.images[index], s_data.shape, ' is too small')

        else:
            raise ValueError('invalid view value')

        crop_seg[np.where(crop_seg == 4)] = 3
        crop_seg[np.where(crop_seg == 5)] = 4
        crop_seg[np.where(crop_seg == 6)] = 5

        crop_origin_tensor = torch.unsqueeze(torch.Tensor(crop_origin), 0)
        crop_tensor = torch.unsqueeze(torch.Tensor(crop), 0)
        seg_tensor = torch.unsqueeze(torch.Tensor(crop_seg), 0)

        # size = [i for i in range(crop_tensor.shape[0])]
        # random.shuffle(size)
        # crop_tensor_sample = crop_tensor[size[:3]]
        # seg_tensor_sample = seg_tensor[size[:3]]
        # print(self.images[index], crop_tensor_sample.shape, seg_tensor_sample.shape)
        return crop_origin_tensor, crop_tensor, seg_tensor

    def __len__(self):
        return len(self.images)

class image_dataset_sagittal_test(Dataset):
    def __init__(self, csv_path, raw_dir, view):
        self.images = []
        df = pd.read_csv(csv_path)
        self.view = view
        self.images += [str(line).zfill(5) for line in list(df['test'].values)]
        self.raw_path = raw_dir
        self.blurSize_min = 18
        self.blurSize_max = 224
        self.scale_factor = 13
        self.whole_size = 221
        if self.view == 'axial':
            self.crop_size = (self.blurSize_max, self.whole_size + 1)
        elif self.view == 'coronal':
            self.crop_size = (self.whole_size + 1, self.blurSize_max)

    def __getitem__(self, index):
        # print(self.images[index])
        s, seg = [nib.load(
            os.path.join(self.raw_path, self.images[index],
                         self.images[index] + '_' + pos + '.nii.gz'))
            for pos in ['sagittal_sp', 'seg_sp']]
        s_data = s.get_fdata()
        seg_data = seg.get_data()

        if self.view == 'axial':
            if s.get_shape()[2] > self.whole_size and s.get_shape()[1] > self.blurSize_max:

                crop_a = np.zeros(s_data.shape)
                crop_a[:, :, ::self.scale_factor] = s_data[:, :, ::self.scale_factor]
                crop_seg = seg_data
                crop = (crop_a - np.min(crop_a)) / (np.max(crop_a) - np.min(np.min(crop_a)))
            else:
                raise ValueError(self.images[index], s.shape, ' is too small')

        elif self.view == 'coronal':
            if s.get_shape()[1] > self.whole_size and s.get_shape()[2] > self.blurSize_max:
                crop_c = np.zeros(s_data.shape)
                crop_c[:, ::self.scale_factor, :] = s_data[:, ::self.scale_factor, :]
                crop_seg = seg_data
                crop = (crop_c - np.min(crop_c)) / (np.max(crop_c) - np.min(np.min(crop_c)))
            else:
                raise ValueError(self.images[index], s.shape, ' is too small')
            # crop_seg = np.zeros(crop.shape)
        elif self.view == 'sagittal':
            crop_s = s_data
            crop_seg = seg_data
            crop = (crop_s - np.min(crop_s)) / (np.max(crop_s) - np.min(np.min(crop_s)))
        else:
            raise ValueError('invalid view value')

        crop_seg[np.where(crop_seg == 4)] = 3
        crop_seg[np.where(crop_seg == 5)] = 4
        crop_seg[np.where(crop_seg == 6)] = 5
        crop_tensor = torch.Tensor(crop)
        seg_tensor = torch.Tensor(crop_seg)

        # size = [i for i in range(crop_tensor.shape[0])]
        # random.shuffle(size)
        # crop_tensor_sample = crop_tensor[size[:3]]
        # seg_tensor_sample = seg_tensor[size[:3]]
        # print(self.images[index], crop_tensor_sample.shape, seg_tensor_sample.shape)
        return crop_tensor, seg_tensor, self.images[index]

    def __len__(self):
        return len(self.images)

def load_data_high(csv_path, raw_path, view, batch_size, shuffle=True):
    valid_dataset = image_dataset(csv_path, raw_path,view)
    valid_loader = data.DataLoader(valid_dataset, batch_size=batch_size,
                                   num_workers=8, shuffle=shuffle)
    return  valid_loader

def load_data_high_sagittal_test(csv_path, raw_path, view, batch_size, shuffle=True):
    valid_dataset = image_dataset_sagittal_test(csv_path, raw_path,view)
    valid_loader = data.DataLoader(valid_dataset, batch_size=1,
                                   num_workers=8, shuffle=False)
    return  valid_loader


def tensor2im(input_image, imtype=np.uint8):
    if isinstance(input_image, torch.Tensor):
        image_tensor = input_image.data
    else:
        return input_image
    image_numpy = image_tensor[0].cpu().float().numpy()
    if image_numpy.shape[0] == 1:
        image_numpy = np.tile(image_numpy, (3, 1, 1))
    image_numpy = np.transpose(image_numpy, (1, 2, 0)) * 256.0 - 0.5
    image_numpy = np.clip(image_numpy, 0, 255)
    return image_numpy.astype(imtype)
