import numpy as np
import os
import pickle
import torch
import torch.nn.functional as F
import torch.utils.data as data
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
import pdb
# from PIL import Image
from torch.autograd import Variable
import numpy as np
import SimpleITK as sitk
from skimage import  transform
# from transform import train_transform, train_crop_transform, \
#     test_transform, test_crop5_transform, test_crop10_transform

# INPUT_DIM = 224
# MAX_PIXEL_VAL = 255
# MEAN = 58.09
# STDDEV = 49.73

class image_dataset(Dataset):
    def __init__(self, path):
        self.path = path
        self.imageList = [line for line in os.listdir(path)]
        # self.transforms = transformfile

    def __getitem__(self, item):
        filePath = self.imageList[item]
        data0 = np.load(os.path.join(self.path, filePath))
        # if data.shape[0] ==2:
        # print(item, filePath, data0.shape)
        a_arr0 = data0[0]
        sa_arr0 = data0[1]
        a_arr0 = (a_arr0-np.min(a_arr0))/(np.max(a_arr0)-np.min(np.min(a_arr0)))

        a_tensor = torch.Tensor(np.expand_dims(a_arr0, axis=0))
        sa_tensor = torch.Tensor(np.expand_dims(sa_arr0, axis=0))
        # print(filePath, a_tensor.max(), sa_tensor.max())
        return a_tensor, sa_tensor, torch.Tensor([a_tensor.min()]).reshape([]), \
                torch.Tensor([a_tensor.max()]).reshape([])

    def __len__(self):
        return len(self.imageList)


def load_data(data_dir, batch_size):
    valid_dataset = image_dataset(data_dir)
    valid_loader = data.DataLoader(valid_dataset, batch_size=batch_size,
                                   num_workers=8, shuffle=True)
    return  valid_loader

def load_data_down(data_dir,):
    valid_dataset = image_dataset_down(data_dir)
    valid_loader = data.DataLoader(valid_dataset, batch_size=6,
                                   num_workers=8, shuffle=True)
    return  valid_loader

class image_dataset_down(Dataset):
    def __init__(self, path):
        self.path = path
        self.imageList = [line for line in os.listdir(path)]
        # self.transforms = transformfile

    def __getitem__(self, item):
        filePath = self.imageList[item]
        data0 = np.load(os.path.join(self.path, filePath))

        sa_arr0 = data0[1]
        a_arr0 = sa_arr0[:,::11]

        a_tensor = torch.Tensor(np.expand_dims(a_arr0, axis=0))
        sa_tensor = torch.Tensor(np.expand_dims(sa_arr0, axis=0))
        # print(a_tensor.shape, sa_tensor.shape)
        return a_tensor, sa_tensor, torch.Tensor([a_tensor.min()]).reshape([]), \
               torch.Tensor([a_tensor.max()]).reshape([])

    def __len__(self):
        return len(self.imageList)


def load_data_eval(data_dir,):
    valid_dataset = image_dataset(data_dir)
    valid_loader = data.DataLoader(valid_dataset, batch_size=32,
                                   num_workers=8, shuffle=True)
    return  valid_loader

def tensor2im(input_image, imtype=np.uint8):
    if isinstance(input_image, torch.Tensor):
        image_tensor = input_image.data
    else:
        return input_image
    image_numpy = image_tensor[0].cpu().float().numpy()
    if image_numpy.shape[0] == 1:
        image_numpy = np.tile(image_numpy, (3, 1, 1))
    image_numpy = np.transpose(image_numpy, (1, 2, 0)) * 256.0 - 0.5
    image_numpy = np.clip(image_numpy, 0, 255)
    return image_numpy.astype(imtype)

# def display_current_results(visuals, epoch, save_result):
#     if len(visuals) == 0:
#         return
#     if self.display_id > 0:  # show images in the browser
#         ncols = self.ncols
#         if ncols > 0:
#             ncols = min(ncols, len(visuals))
#             h, w = next(iter(visuals.values())).shape[:2]
#             table_css = """<style>
#                     table {border-collapse: separate; border-spacing:4px; white-space:nowrap; text-align:center}
#                     table td {width: %dpx; height: %dpx; padding: 4px; outline: 4px solid black}
#                     </style>""" % (w, h)
#             title = self.name
#             label_html = ''
#             label_html_row = ''
#             images = []
#             idx = 0
#             for label, image in visuals.items():
#                 image_numpy = tensor2im(image)
#                 label_html_row += '<td>%s</td>' % label
#                 images.append(image_numpy.transpose([2, 0, 1]))
#                 idx += 1
#                 if idx % ncols == 0:
#                     label_html += '<tr>%s</tr>' % label_html_row
#                     label_html_row = ''
#                 self.vis.image(image_numpy.transpose([2,0,1]), \
#                         win=self.display_id + 3 + idx, \
#                         opts=dict(title=title + ' images ' + label))
#             white_image = np.ones_like(image_numpy.transpose([2, 0, 1])) * 255
#             while idx % ncols != 0:
#                 images.append(white_image)
#                 label_html_row += '<td></td>'
#                 idx += 1
#             if label_html_row != '':
#                 label_html += '<tr>%s</tr>' % label_html_row
#             # pane col = image row
#             try:
#                 #self.vis.images(images, nrow=ncols, win=self.display_id + 1,
#                 #                padding=2, opts=dict(title=title + ' images'))
#                 label_html = '<table>%s</table>' % label_html
#                 self.vis.text(table_css + label_html, win=self.display_id + 2,
#                               opts=dict(title=title + ' labels'))
#             except VisdomExceptionBase:
#                 self.throw_visdom_connection_error()
#
#         else:
#             idx = 1
#             for label, image in visuals.items():
#                 image_numpy = tensor2im(image)
#                 vis.image(image_numpy.transpose([2, 0, 1]), opts=dict(title=label),
#                                win=self.display_id + idx)
#                 idx += 1
#
#     if self.use_html and (save_result or not self.saved):  # save images to a html file
#         self.saved = True
#         for label, image in visuals.items():
#             image_numpy = util.tensor2im(image)
#             img_path = os.path.join(self.img_dir, 'epoch%.3d_%s.png' % (epoch, label))
#             util.save_image(image_numpy, img_path)
#         # update website
#         webpage = html.HTML(self.web_dir, 'Experiment name = %s' % self.name, reflesh=1)
#         for n in range(epoch, 0, -1):
#             webpage.add_header('epoch [%d]' % n)
#             ims, txts, links = [], [], []
#
#             for label, image_numpy in visuals.items():
#                 image_numpy = util.tensor2im(image)
#                 img_path = 'epoch%.3d_%s.png' % (n, label)
#                 ims.append(img_path)
#                 txts.append(label)
#                 links.append(img_path)
#             webpage.add_images(ims, txts, links, width=self.win_size)
#         webpage.save()
