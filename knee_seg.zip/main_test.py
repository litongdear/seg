import torch
import argparse
import matplotlib.pyplot as plt
import os
import numpy as np
import torch
import torch.nn.functional as F
# from tqdm import tqdm
from model import unet, fcn, srUnet
import pdb
import visdom
from pathlib import Path
import json
import SimpleITK as sitk
from collections import OrderedDict
from evaluate.metrics import ConfusionMatrix
from sklearn import metrics
from torch.autograd import Variable
from data.coronal_down_loader import load_data_lowHigh, align2RAS, load_data_lowHigh_sagittal_test
from utils.nii_func import getSpacing, build_affine
import pandas as pd
import nibabel as nib
import imageio
from utils.nd_softmax import softmax_helper
from loss.dice_loss import DC_and_CE_loss

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def confusion_matrix(softmax_pred, gt_segmentation, global_fn=None, global_fp=None, global_tp=None):

    # print(softmax_pred.shape, gt_segmentation.shape)
    predicted_segmentation = softmax_pred.argmax(1)
    gt_segmentation = torch.squeeze(gt_segmentation.long())
    # y_onehot = torch.zeros(softmax_pred.shape)
    # if net_output.device.type == "cuda":
    #     y_onehot = y_onehot.cuda(net_output.device.index)
    # y_onehot.scatter_(1, gt_segmentation, 1)
    labels = [i for i in range(args.num_class)]
    labels = [int(i) for i in labels if i > 0]
    # predicted_segmentation = np.expand_dims(predicted_segmentation.cpu().data.numpy(), 0)
    for l in labels:
        if l not in global_fn.keys():
            global_fn[l] = 0
        if l not in global_fp.keys():
            global_fp[l] = 0
        if l not in global_tp.keys():
            global_tp[l] = 0

        conf = ConfusionMatrix((predicted_segmentation.cpu().data.numpy() == l).astype(int),
                               (gt_segmentation.data.numpy() == l).astype(int))
        conf.compute()
        global_fn[l] += conf.fn
        global_fp[l] += conf.fp
        global_tp[l] += conf.tp

    # print(global_tp)
    return global_fn, global_fp, global_tp

def eval_dice(args, model, logdir, epoch):
    print('loading state dict:%s'%(logdir + str(epoch) + '.pkl'))
    state_dict = torch.load(logdir + str(epoch) + '.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()

    # thick_dir = os.path.join(resultdir, 'seg_mask')
    # path_exist(thick_dir)
    global_tp = OrderedDict()
    global_fp = OrderedDict()
    global_fn = OrderedDict()
    global_dice = OrderedDict()

    test_pd = pd.read_csv(args.test_csv)
    test_list = test_pd['test']

    for id in test_list:
        num = str(id).zfill(5)
        img_path = os.path.join(args.test_datadir, num+'_'+args.view+'.nii.gz')
        aa = nib.load(img_path)
        seg_path = os.path.join(args.test_datadir, num+'_coronao'+'_mask.nii.gz')
        seg = nib.load(seg_path)

        seg_data = seg.get_data().astype(np.int32)
        img_data = aa.get_fdata()
        img_shape = aa.get_shape()
        # spacing = getSpacing(aa)
        # new_spacing = [min(spacing), min(spacing), min(spacing)]
        # new_affine = build_affine(new_spacing, aa)
        # minVal, maxVal = np.min(img_arr), np.max(img_arr)
        # img_arr = np.zeros((img_shape[0], img_shape[1], (img_shape[2]-1)*13+1))

        # if args.view == 'axial':
        #     img_arr = np.zeros((img_shape[0], img_shape[1], (img_shape[2] - 1) * 13 + 1))
        #     img_arr[:, :, ::13] = img_data
        # elif args.view == 'coronal':
        #     img_arr = np.zeros((img_shape[0], (img_shape[1] - 1) * 13 + 1, img_shape[2]))
        #     img_arr[:, ::13, :] = img_data
        # else:
        #     raise ValueError('wrong view str')
        img_arr = np.transpose(img_data, [1, 0, 2])
        seg_arr = np.transpose(seg_data, [1, 0, 2])
        img_arr_1 = (img_arr-np.min(img_arr))/(np.max(img_arr)-np.min(img_arr))
        img_tensor = torch.Tensor(np.expand_dims(img_arr_1, 1))
        img_tensor = img_tensor.cuda()
        seg_tensor = torch.Tensor(np.expand_dims(seg_arr, 1))
        # seg_tensor = seg_tensor.cuda()
        with torch.no_grad():
            output = model(img_tensor)
            output = softmax_helper(output)
            global_fn, global_fp, global_tp = confusion_matrix(output, seg_tensor, global_fn, global_fp, global_tp)
            print('llll')
        labels = [i for i in range(args.num_class)]
        labels = [int(i) for i in labels if i > 0]
        # predicted_segmentation = np.expand_dims(predicted_segmentation.cpu().data.numpy(), 0)
        for l in labels:
            if global_tp[l] == 0:
                global_dice[l] = 0
            else:
                global_dice[l] = 2 * global_tp[l] / (2 * global_tp[l] + global_fn[l] + global_fp[l])

    print(logdir)
    print(global_tp)
    print(global_fn)
    print('Epoch_%d | 1:%.4f 2:%.4f 3:%.4f 4:%.4f 5:%.4f\n'
                 %(epoch, global_dice[1], global_dice[2],global_dice[3], global_dice[4], global_dice[5]))

def get_parser():
    parser = argparse.ArgumentParser()
    # parser.add_argument('--rundir', default='/share/litong/knee/blur_seg/seg_log/', type=str)
    parser.add_argument('--test_datadir', default='/share/litong/knee/cycle_seg/data/GT_test/',
                        type=str)
    parser.add_argument('--npydir', default='/share/litong/knee/cycle_seg/data/crop_sagittal_npy/',
                        type=str)
    parser.add_argument('--test_csv', default='/share/litong/knee/cycle_seg/data/GT_test.csv',
                        type=str)
    parser.add_argument('--seg_pkl',
                        default='/share/litong/knee/blur_seg/seg_log/coronal_down2_UNet_coronal_6/',
                        type=str)
    parser.add_argument('--seg_pkl_epoch', default=57, type=int)

    parser.add_argument('--is_training', default=False, type=bool)
    parser.add_argument('--view', default='coronal', type=str)
    parser.add_argument('--model_name', default='UNet', type=str)
    parser.add_argument('--use_view', default=False, type=bool)
    parser.add_argument('--bilinear', default=False, type=bool)
    parser.add_argument('--gpu', default=1, type=int)  # action='store_true'

    parser.add_argument('--context_num', default=1, type=int)  # action='store_true'
    parser.add_argument('--num_class', default=6, type=int)  # action='store_true'

    parser.add_argument('--learning_rate', default=3e-4, type=float)

    # parser.add_argument('--task', default='by', type=str)
    parser.add_argument('--seed', default=42, type=int)
    parser.add_argument('--weight_decay', default=3e-5, type=float)  # 0.01
    parser.add_argument('--EPOCH', default=200, type=int)
    parser.add_argument('--batch_size', default=2, type=int)
    parser.add_argument('--max_patience', default=30, type=int)
    parser.add_argument('--factor', default=0.8, type=float)

    parser.add_argument('--lambda_L1', type=float, default=1, \
                           help='weight for L1 loss')
    parser.add_argument('--lambda_gan', type=float, default=0, \
                           help='weight for gan loss')
    parser.add_argument('--lr', type=float, default=0.00002, \
                           help='learning rate')
    parser.add_argument('--imgsz', type=int, default=256, \
                           help='imgsz')
    parser.add_argument('--z_dim', type=int, default=512, \
                           help='hidden latent z dim')
    parser.add_argument('--ch_G', type=int, default=32, \
                           help='number of feature maps for generator (encoder-decoder)')
    parser.add_argument('--ch_D', type=int, default=64, \
                           help='number of feature maps for discriminator')
    parser.add_argument('--ch_io', type=int, default=1, \
                           help='number of channels for image')
    parser.add_argument('--layers_D', type=int, default=3, \
                           help='depth of conv for discriminator')
    return parser

if __name__ == '__main__':

    args = get_parser().parse_args()
    os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)

    if args.model_name=='UNet':
        model = unet.UNet(n_channels=args.context_num, n_classes=args.num_class,
                          use_view=args.use_view,
                          bilinear=args.bilinear, view=args.view)

    elif args.model_name=='srUNet':
        model = srUnet.UNet(n_channels=args.context_num, n_classes=args.num_class,
                          use_view=args.use_view,
                          bilinear=args.bilinear, view=args.view)
    elif args.model_name=='FCN':
        model = fcn.FCN(n_channels=args.context_num, n_classes=args.num_class,
                        use_view=args.use_view,
                          bilinear=args.bilinear, view=args.view)

    else:
        raise ValueError('model name is not valid!')

    model.cuda()
    eval_dice(args, model, args.seg_pkl, args.seg_pkl_epoch) # 27
