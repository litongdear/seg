import torch
import numpy as np
import os
from utils import nii_func
import nibabel as nib
from main_coronal import path_exist

coronal_data_path = '/share/litong/knee/cycle_seg/data/crop/'
coronal_path = '/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_coronal_6/'
axial_path = '/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_axial_6/'
# file = '00067_coronal_mask.nii.gz'
save_path = '/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_coronal_6/overlap/'
save_thick_path = '/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_coronal_6/overlap_thick/'

interp_path = '/share/litong/knee/blur_seg/seg_log/result/down_UNet_sagittal_6/interp/'

path_exist(save_path)
path_exist(save_thick_path)

# for file in os.listdir(coronal_path):
#     num = file.split('_')[0]
num = '00283'
cornal_data = nii_func.align2RAS(nib.load(os.path.join(coronal_data_path,num, num+'_coronal.nii.gz')))
sagittal_data = nii_func.align2RAS(nib.load(os.path.join(interp_path, '00283_sagittal_sp306_interp_sagittal_306.nii.gz')))
seg = nii_func.align2RAS(nib.load(os.path.join(interp_path,'00283_sagittal_sp306_interp_sagittal_mask_306.nii.gz')))

# cornal_mask = nii_func.align2RAS(nib.load(os.path.join(coronal_path, file)))
# axial_mask = nii_func.align2RAS(nib.load(os.path.join(axial_path, num+'_axial_mask.nii.gz')))
grid = nii_func.affine2Grids_original(cornal_data.affine, cornal_data.shape, sagittal_data)
# grid = nii_func.affine2Grids_original(axial_mask.affine, axial_mask.shape, cornal_mask)
print(grid[0][0].shape)
mask_tensor = torch.Tensor(seg.get_data().T)
# axial_mask_tensor = torch.Tensor(axial_mask.get_data().T)

c_grid = torch.Tensor(grid[0][0])
c_mask = torch.nn.functional.grid_sample(mask_tensor.unsqueeze(0).unsqueeze(0),
                                c_grid.unsqueeze(0), mode='nearest')

c_mask_arr = c_mask.squeeze().data.numpy().T.astype(np.float)
print(c_mask_arr.shape)

# ac_mask = nib.Nifti1Image(a_mask_arr, cornal_mask.affine)
# nib.save(ac_mask, os.path.join(coronal_path, num+'_coronal_a_mask.nii.gz'))

# c_arr = cornal_mask.get_data().astype(np.float)
# c_arr_a = np.where(c_arr==a_mask_arr, 1.0, 0.0)

ac_mask = nib.Nifti1Image(c_mask_arr, cornal_data.affine)
# ac_1_mask = nib.Nifti1Image(c_arr_a[:,::13,:], cornal_data.affine)
nib.save(ac_mask, os.path.join(interp_path, num+'_coronal_mask_sp306.nii.gz'))
nib.save(cornal_data, os.path.join(interp_path, num+'_coronal.nii.gz'))

# nib.save(ac_1_mask, os.path.join(save_thick_path, num + '_c_mask.nii.gz'))

print('lll')
# torch.nn.functional.interpolate()
# torch.nn.modules.upsampling(qw, wde)
