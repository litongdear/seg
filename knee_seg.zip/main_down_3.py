import torch
import argparse
import matplotlib.pyplot as plt
import os
import numpy as np
import torch
import torch.nn.functional as F
# from tqdm import tqdm
from model import unet, fcn, srUnet
import pdb
import visdom
from pathlib import Path
import json
import SimpleITK as sitk
from collections import OrderedDict
from evaluate.metrics import ConfusionMatrix
from sklearn import metrics
from torch.autograd import Variable
from data.down_loader_3 import load_data_lowHigh, align2RAS, load_data_lowHigh_sagittal_test
from utils.nii_func import getSpacing, build_affine
import nibabel as nib
import imageio
from utils.nd_softmax import softmax_helper
from loss.dice_loss import DC_and_CE_loss

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def training_model(args, log, model, train_loader,
                   optimizer=None, loss_func=None, scheduler=None, ):

    env_name = log.split('/')[-2]
    print(env_name)
    viz = visdom.Visdom(env=log.split('/')[-2])
    f = open(os.path.join(log, 'loss.txt'), 'a')
    train_dc_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='train_dc_loss'))
    train_ce_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='train_ce_loss'))
    train_loss_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='train_all_loss'))
    lr_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='lr'))

    for epoch in range(args.EPOCH):
        model.train(True)
        for step, (b_x, b_y) in enumerate(train_loader):
            iter_count = epoch * len(train_loader) + step
            # gives batch data
            _, _, h, w = b_x.shape
            b_x = b_x.view(-1, 1, h, w)
            b_y = b_y.view(-1, 1, h, w)
            b_x = b_x.cuda()
            b_y = b_y.cuda()

            output = model(b_x)
            # output = softmax_helper(output)

            # b_y_min, b_y_max = torch.min(b_y), torch.max(b_y)
            # output_min, output_max = torch.min(output), torch.max(output)
            # loss0 = torch.mean(torch.abs(b_y-output))
            loss, ce_loss, dc_loss = loss_func(output, b_y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            scheduler.step(loss)
            lr = optimizer.param_groups[0]['lr']

            viz.line(X=np.array([iter_count]), Y=np.array([dc_loss.cpu().data]), update='append', win=train_dc_win)
            viz.line(X=np.array([iter_count]), Y=np.array([ce_loss.cpu().data]), update='append', win=train_ce_win)
            viz.line(X=np.array([iter_count]), Y=np.array([loss.cpu().data]), update='append', win=train_loss_win)
            viz.line(X=np.array([epoch]), Y=np.array([lr]), update='append', win=lr_win)
            print('Epoch: %d | step: %d | loss: %.4f | ce_loss: %.4f | dc_loss: %.4f' %
                  (epoch, step, loss.cpu().data, ce_loss.cpu().data, dc_loss.cpu().data))
            f.writelines('Epoch: %d | step: %d | loss: %.4f | ce_loss: %.4f | dc_loss: %.4f\n' %
                         (epoch, step, loss.cpu().data, ce_loss.cpu().data, dc_loss.cpu().data))
        log_path = log + str(epoch) + '.pkl'
        torch.save(model.state_dict(), log_path)
    f.close()

def train_main(args, model, logdir):
    train_loader = load_data_lowHigh(args, args.csv_path, args.datadir, args.view, args.batch_size)
    optimizer = torch.optim.Adam(model.parameters(), args.learning_rate,
                                 weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=args.max_patience, factor=args.factor,
                                                           threshold=1e-7)
    # loss_func = torch.nn.L1Loss()
    loss_func = DC_and_CE_loss({'batch_dice': True, 'smooth': 1e-5, 'do_bg': False,
                                'square': False}, {})

    training_model(args, logdir, model, train_loader,
                   optimizer=optimizer, loss_func=loss_func, scheduler=scheduler)

def confusion_matrix(softmax_pred, gt_segmentation, global_fn=None, global_fp=None, global_tp=None):

    # print(softmax_pred.shape, gt_segmentation.shape)
    predicted_segmentation = softmax_pred.argmax(1)
    gt_segmentation = torch.squeeze(gt_segmentation.long())
    # y_onehot = torch.zeros(softmax_pred.shape)
    # if net_output.device.type == "cuda":
    #     y_onehot = y_onehot.cuda(net_output.device.index)
    # y_onehot.scatter_(1, gt_segmentation, 1)
    labels = [i for i in range(args.num_class)]
    labels = [int(i) for i in labels if i > 0]
    # predicted_segmentation = np.expand_dims(predicted_segmentation.cpu().data.numpy(), 0)
    for l in labels:
        if l not in global_fn.keys():
            global_fn[l] = 0
        if l not in global_fp.keys():
            global_fp[l] = 0
        if l not in global_tp.keys():
            global_tp[l] = 0

        conf = ConfusionMatrix((predicted_segmentation.cpu().data.numpy() == l).astype(int),
                               (gt_segmentation.data.numpy() == l).astype(int))
        conf.compute()
        global_fn[l] += conf.fn
        global_fp[l] += conf.fp
        global_tp[l] += conf.tp

    # print(global_tp)
    return global_fn, global_fp, global_tp

def eval(args, model, logdir, epoch):
    state_dict = torch.load(logdir+str(epoch)+'.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()
    for dir in os.listdir(args.testdir):
        with torch.no_grad():
            b_img = sitk.ReadImage(os.path.join(args.testdir, dir, 'axial_full_crop.nii.gz'))

            img_sa_arr = sitk.GetArrayFromImage(b_img)
            img_sa_arr = np.transpose(img_sa_arr, [2,1,0])
            img_sa_arr = np.expand_dims(img_sa_arr, axis=1)
            b_arr = img_sa_arr - np.min(img_sa_arr) / (np.max(img_sa_arr) - np.min(img_sa_arr))
            b_arr = torch.Tensor(b_arr)
            b_x = b_arr.cuda()  # reshape x to (batch, time_step, input_size)
            print(b_x.shape)
            # b_y = b_y.cuda()
            output = np.zeros(b_x.shape)
            for i in range(4):
                out = model(b_x[i*132:(i+1)*132, :, :, :]).cpu().data.numpy()
                print(out.shape)
                output[i*132:(i+1)*132, :, :, :] = out

            output = np.squeeze(output, axis=1)
            output = np.transpose(output, [2,1,0])
            full_a_arr_img = sitk.GetImageFromArray(output)
            full_a_arr_img.SetSpacing(b_img.GetSpacing())
            full_a_arr_img.SetOrigin(b_img.GetOrigin())
            full_a_arr_img.SetDirection(b_img.GetDirection())
            save_dir = args.resultdir + logdir.split('/')[-2]
            path_exist(save_dir)
            save_name = os.path.join(save_dir, dir+'_rect_'+str(epoch)+'.nii.gz')
            sitk.WriteImage(full_a_arr_img, save_name)
            del full_a_arr_img, output, b_img

def eval_tiff(args, file, model):
    # for dir in os.listdir(args.datadir):
    file_name = np.load(os.path.join(args.datadir, file))[0, :, :]  #'14535_9.npy'
    gt = np.load(os.path.join(args.datadir, file))[1, :, :]
    # gt = np.expand_dims(gt, axis=0)
    gt_tensor = torch.Tensor(np.expand_dims(gt, axis=0))

    file_arr = np.expand_dims(file_name, axis=0)
    file_arr = np.expand_dims(file_arr, axis=0)
    file_arr = (file_arr-np.min(file_arr))/(np.max(file_arr)-np.min(file_arr))
    file_tensor = torch.Tensor(file_arr).cuda()
    output = model(file_tensor)
    output = softmax_helper(output)
    global_dice = confusion_matrix(output, gt_tensor)
    return global_dice

    # save_dir = args.resultdir + logdir.split('/')[-2]+'/'
    # path_exist(save_dir)
    # imageio.imwrite(save_dir + '05270_7' + '_a.tiff', np.squeeze(output))
    # imageio.imwrite(save_dir + '05270_7' + '_sa.tiff', gt)

def get_img_param(img):
    spacing = img.GetSpacing()
    size = img.GetSize()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    arr = sitk.GetArrayFromImage(img)
    return  arr, spacing, size, origin, direction

def writeImg(arr, spacing, origin, direction, path):
    img = sitk.GetImageFromArray(arr)
    img.SetOrigin(origin)
    img.SetSpacing(spacing)
    img.SetDirection(direction)
    sitk.WriteImage(img, path)

def eval_func():
    pass

def eval_sample_nii(args, model, logdir, epoch, resultdir):
    print('loading state dict:%s'%(logdir + str(epoch) + '.pkl'))
    state_dict = torch.load(logdir + str(epoch) + '.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()

    thick_dir = os.path.join(resultdir, 'seg_mask_ep'+str(epoch))
    path_exist(thick_dir)

    for num in os.listdir(args.test_datadir):
        # num = file.split('_')[0]
        img_path = os.path.join(args.test_datadir, num, num+'_'+args.view+'.nii.gz')
        aa = nib.load(img_path)
        # img = align2RAS(nib.load(img_path))
        img_data = aa.get_fdata()
        img_shape = aa.get_shape()
        spacing = getSpacing(aa)
        new_spacing = [min(spacing), min(spacing), min(spacing)]
        new_affine = build_affine(new_spacing, aa)
        # minVal, maxVal = np.min(img_arr), np.max(img_arr)
        # img_arr = np.zeros((img_shape[0], img_shape[1], (img_shape[2]-1)*13+1))

        # if args.view == 'axial':
        #     img_arr = np.zeros((img_shape[0], img_shape[1], (img_shape[2] - 1) * 13 + 1))
        #     img_arr[:, :, ::13] = img_data
        # elif args.view == 'coronal':
        #     img_arr = np.zeros((img_shape[0], (img_shape[1] - 1) * 13 + 1, img_shape[2]))
        #     img_arr[:, ::13, :] = img_data
        # else:
        #     raise ValueError('wrong view str')
        img_arr = img_data
        img_arr_1 = (img_arr-np.min(img_arr))/(np.max(img_arr)-np.min(img_arr))
        img_tensor = torch.Tensor(np.expand_dims(img_arr_1, 1))
        img_tensor = img_tensor.cuda()
        # mask_tensor = torch.zeros(img_arr_1.shape)

        # if img_tensor.shape[0] >30:
        #     block_nums = 10
        # else:
        #     block_nums = 1
        # tmp_num = img_tensor.shape[0]//block_nums+1
        #
        # for i in range(block_nums):
        #     print(i)
        #     if i < block_nums-1:
        #         start_index, end_index = i*tmp_num, (i+1)*tmp_num
        #     else:
        #         start_index, end_index = i*tmp_num, img_tensor.shape[0]+1
        #
        #     img_tmp_tensor = img_tensor[start_index:end_index, :, :, :]

        with torch.no_grad():
            output = model(img_tensor)
            output = output.argmax(dim=1)
            # mask_tensor[start_index:end_index, :, :] = output
            mask_seg = output.cpu().data.numpy().astype(np.float64)

        img_mask = nib.Nifti1Image(mask_seg.copy(), aa.affine)
        nib.save(img_mask, thick_dir+'/' + num + '_' + args.view + '_mask.nii.gz')


def eval_sample_dice_sagittal_npy(args, model, logdir, epoch, f):
    state_dict = torch.load(logdir + str(epoch) + '.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()
    num_list =[]
    flag = True
    global_tp = OrderedDict()
    global_fp = OrderedDict()
    global_fn = OrderedDict()
    global_dice = OrderedDict()

    # train_loader = load_data_lowHigh(args.datadir, args.batch_size, args.context_num, shuffle=False)
    train_loader = load_data_lowHigh(args.csv_path, args.datadir, args.view, args.batch_size)
    with torch.no_grad():
        for step, (b_x, b_y) in enumerate(train_loader):
            iter_count = epoch * len(train_loader) + step
            # gives batch data
            b_x = b_x.cuda()
            output = model(b_x)
            output = softmax_helper(output)
            global_fn, global_fp, global_tp = confusion_matrix(output, b_y, global_fn, global_fp, global_tp)
            # print('llll')
    labels = [i for i in range(args.num_class)]
    labels = [int(i) for i in labels if i > 0]
    # predicted_segmentation = np.expand_dims(predicted_segmentation.cpu().data.numpy(), 0)
    for l in labels:
        if global_tp[l] == 0:
            global_dice[l] = 0
        else:
            global_dice[l] = 2 * global_tp[l] / (2 * global_tp[l] + global_fn[l] + global_fp[l])

    f.writelines('Epoch_%d | 1:%.4f 1:%.4f 1:%.4f 1:%.4f 1:%.4f\n'
                 %(epoch, global_dice[1], global_dice[2],global_dice[3], global_dice[4], global_dice[5]))
    print('Epoch_', epoch, global_dice)

def eval_sample_dice_sagittal_nii(args, model, logdir, epoch, f):
    state_dict = torch.load(logdir + str(epoch) + '.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()
    num_list =[]
    flag = True
    global_tp = OrderedDict()
    global_fp = OrderedDict()
    global_fn = OrderedDict()
    global_dice = OrderedDict()

    # train_loader = load_data_lowHigh(args.datadir, args.batch_size, args.context_num, shuffle=False)
    train_loader = load_data_lowHigh_sagittal_test(args.eval_csv_path, args.datadir,
                                                   args.view, args.batch_size)
    with torch.no_grad():
        for step, (b_x, b_y, file_name) in enumerate(train_loader):
            iter_count = epoch * len(train_loader) + step
            # gives batch data

            b_x = b_x.cuda()
            b_x = b_x.permute(1, 0, 2,3)
            b_y = b_y.permute(1, 0, 2, 3)
            # print('b_x shape', b_x.shape, file_name)
            output = model(b_x)
            output = softmax_helper(output)
            global_fn, global_fp, global_tp = confusion_matrix(output, b_y, global_fn, global_fp, global_tp)
            # print('llll')
    labels = [i for i in range(args.num_class)]
    labels = [int(i) for i in labels if i > 0]
    # predicted_segmentation = np.expand_dims(predicted_segmentation.cpu().data.numpy(), 0)
    for l in labels:
        if global_tp[l] == 0:
            global_dice[l] = 0
        else:
            global_dice[l] = 2 * global_tp[l] / (2 * global_tp[l] + global_fn[l] + global_fp[l])

    f.writelines('Epoch_%d | 1:%.4f 2:%.4f 3:%.4f 4:%.4f 5:%.4f\n'
                 %(epoch, global_dice[1], global_dice[2],global_dice[3], global_dice[4], global_dice[5]))
    print('Epoch_', epoch, global_dice)

def get_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--rundir', default='/share/litong/knee/blur_seg/seg_log/', type=str)
    parser.add_argument('--datadir', default='/share/litong/knee/cycle_seg/data/crop/',
                        type=str)
    parser.add_argument('--npydir', default='/share/litong/knee/cycle_seg/data/crop_sagittal_npy/',
                        type=str)
    parser.add_argument('--test_datadir', default='/share/litong/knee/cycle_seg/data/crop/',
                        type=str)
    parser.add_argument('--csv_path', default='/share/litong/knee/cycle_seg/data/train.csv',
                        type=str)
    parser.add_argument('--eval_csv_path', default='/share/litong/knee/cycle_seg/data/test.csv',
                        type=str)
    parser.add_argument('--resultdir', default='/share/litong/knee/blur_seg/seg_log/result/',
                        type=str)
    parser.add_argument('--coronal_segdir',
                        default='/share/litong/knee/blur_seg/seg_log/result/coronal_down_UNet_coronal_6/',
                        #'/share/litong/knee/blur_seg/seg_log/result/lowHigh_UNet_coronal_6/',
                        type=str)
    parser.add_argument('--axial_segdir',
                        default='/share/litong/knee/blur_seg/seg_log/result/coronal_down_UNet_axial_6/',
                        type=str)

    parser.add_argument('--is_training', default=True, type=bool)
    parser.add_argument('--view', default='coronal', type=str)
    parser.add_argument('--name', default='down3', type=str)
    parser.add_argument('--model_name', default='UNet', type=str)
    parser.add_argument('--use_view', default=True, type=bool)
    parser.add_argument('--bilinear', default=False, type=bool)
    parser.add_argument('--gpu', default=2, type=int)  # action='store_true'
    parser.add_argument('--context_num', default=1, type=int)  # action='store_true'
    parser.add_argument('--num_class', default=6, type=int)  # action='store_true'
    parser.add_argument('--learning_rate', default=3e-4, type=float)

    # parser.add_argument('--task', default='by', type=str)
    parser.add_argument('--seed', default=42, type=int)
    parser.add_argument('--weight_decay', default=3e-5, type=float)  # 0.01
    parser.add_argument('--EPOCH', default=200, type=int)
    parser.add_argument('--batch_size', default=1, type=int)
    parser.add_argument('--max_patience', default=30, type=int)
    parser.add_argument('--factor', default=0.8, type=float)

    parser.add_argument('--lambda_L1', type=float, default=1, \
                           help='weight for L1 loss')
    parser.add_argument('--lambda_gan', type=float, default=0, \
                           help='weight for gan loss')
    parser.add_argument('--lr', type=float, default=0.00002, \
                           help='learning rate')
    parser.add_argument('--imgsz', type=int, default=256, \
                           help='imgsz')
    parser.add_argument('--z_dim', type=int, default=512, \
                           help='hidden latent z dim')
    parser.add_argument('--ch_G', type=int, default=32, \
                           help='number of feature maps for generator (encoder-decoder)')
    parser.add_argument('--ch_D', type=int, default=64, \
                           help='number of feature maps for discriminator')
    parser.add_argument('--ch_io', type=int, default=1, \
                           help='number of channels for image')
    parser.add_argument('--layers_D', type=int, default=3, \
                           help='depth of conv for discriminator')
    return parser

if __name__ == '__main__':

    args = get_parser().parse_args()
    # print(args.task)
    # np.random.seed(args.seed)
    # torch.manual_seed(args.seed)
    # if args.gpu:
    #     torch.cuda.manual_seed_all(args.seed)

    os.makedirs(args.rundir, exist_ok=True)
    os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
    if args.model_name=='UNet':
        model = unet.UNet(n_channels=args.context_num, n_classes=args.num_class,
                          use_view=args.use_view,
                          bilinear=args.bilinear, view=args.view)
        model.load_state_dict(torch.load(
            '/share/litong/knee/blur_seg/seg_log/down_UNet_axial_6/195.pkl'))

    elif args.model_name=='srUNet':
        model = srUnet.UNet(n_channels=args.context_num, n_classes=args.num_class,
                          use_view=args.use_view,
                          bilinear=args.bilinear, view=args.view)
    elif args.model_name=='FCN':
        model = fcn.FCN(n_channels=args.context_num, n_classes=args.num_class,
                        use_view=args.use_view,
                          bilinear=args.bilinear, view=args.view)
    else:
        raise ValueError('model name is not valid!')

    model.cuda()
    resultdir_name = args.name+'_'+args.model_name+'_'+args.view+'_6/'
    logdir = args.rundir + resultdir_name
    print(logdir)

    if args.is_training:
        if not os.path.exists(logdir):
            os.makedirs(logdir)

        with open(Path(logdir) / 'args.json', 'w') as out:
            json.dump(vars(args), out, indent=4)

        train_main(args, model, logdir)

    else:
        resultdir = args.resultdir + resultdir_name  # '/axial_seg1/test/'
        print('save dir:', resultdir)
        path_exist(resultdir)
        eval_sample_nii(args, model, logdir, 106, resultdir)

        # f = open(logdir+'eval_dice.txt', 'w')
        # print(args.eval_csv_path)
        # for ep in range(0, 199, 3):
        #     eval_sample_dice_sagittal_nii(args, model, logdir, ep, f)