
import torch
import torch.nn as nn
import torch.nn.functional as F


class DoubleConv(nn.Module):
    """(convolution => [BN] => ReLU) * 2"""

    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.double_conv(x)


class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        return self.conv(x)


class Down(nn.Module):
    """Downscaling with maxpool then double conv"""

    def __init__(self, in_channels, out_channels, view, use_view=True):
        super().__init__()
        self.view = view
        if use_view:
            if self.view == 'coronal':
                self.maxpool_conv = nn.Sequential(
                    nn.MaxPool2d((3, 3), stride=(1, 2)),
                    # nn.MaxPool2d(2),
                    DoubleConv(in_channels, out_channels))
            if self.view == 'axial':
                self.maxpool_conv = nn.Sequential(
                    nn.MaxPool2d((3, 3), stride=(2, 1)),
                    # nn.MaxPool2d(2),
                    DoubleConv(in_channels, out_channels))
        else:
            self.maxpool_conv = nn.Sequential(
                # nn.MaxPool2d((3, 3), stride=(2, 2)),
                nn.MaxPool2d(2),
                DoubleConv(in_channels, out_channels))

    def forward(self, x):

        return self.maxpool_conv(x)

class FCN(nn.Module):
    def __init__(self, n_channels, n_classes, view, use_view, bilinear):
        super(FCN, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear

        self.inc = DoubleConv(n_channels, 64) # 224
        self.conv1 = nn.Sequential(
            # Down(64, 128, view, use_view), # 112
            # Down(128, 256, view, use_view),  # 56
            DoubleConv(64,128),
            DoubleConv(128,128),)
        self.conv2 = nn.Sequential(
            # nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2), # 224
            DoubleConv(128, 64),
            OutConv(64, 64),
            OutConv(64, n_classes)
        )
        # self.down1 = Down(64, 128, view, use_view)
        # self.down2 = Down(128, 256, view, use_view)
        # self.down3 = Down(256, 512, view, use_view)
        # self.down4 = Down(512, 512, view, use_view)
        # self.up1 = Up(1024, 256, view, use_view, bilinear)
        # self.up2 = Up(512, 128, view, use_view, bilinear)
        # self.up3 = Up(256, 64, view, use_view, bilinear)
        # self.up4 = Up(128, 64, view, use_view, bilinear)
        # self.outc = OutConv(64, n_classes)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.conv1(x1)
        logits = self.conv2(x2)
        return logits
