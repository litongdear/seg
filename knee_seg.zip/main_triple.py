import torch
import argparse
import matplotlib.pyplot as plt
import os
import numpy as np
import torch
import torch.nn.functional as F
# from tqdm import tqdm
from model import unet
import pdb
import visdom
from pathlib import Path
import json
import SimpleITK as sitk
from collections import OrderedDict
from evaluate.metrics import ConfusionMatrix
from sklearn import metrics
from torch.autograd import Variable
from data.triple_loader import triple_load_data, triple_load_data_test, tensor2im, load_data_down
import imageio
from utils.nd_softmax import softmax_helper
from loss.dice_loss import DC_and_CE_loss

def path_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

def training_model(args, log, model, train_loader,
                   optimizer=None, loss_func=None, scheduler=None, ):

    env_name = log.split('/')[-2]
    print(env_name)
    viz = visdom.Visdom(env=log.split('/')[-2])

    train_dc_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='train_dc_loss'))
    train_ce_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='train_ce_loss'))
    train_loss_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='train_all_loss'))
    lr_win = viz.line(X=np.array([0]), Y=np.array([0]), opts=dict(title='lr'))

    for epoch in range(args.EPOCH):
        model.train(True)
        for step, (b_x, b_y, minVal, maxVal) in enumerate(train_loader):
            iter_count = epoch * len(train_loader) + step
            # gives batch data
            b_x = b_x.cuda()
            b_y = b_y.cuda()

            output = model(b_x)
            # output = softmax_helper(output)

            # b_y_min, b_y_max = torch.min(b_y), torch.max(b_y)
            # output_min, output_max = torch.min(output), torch.max(output)
            # loss0 = torch.mean(torch.abs(b_y-output))
            loss, ce_loss, dc_loss = loss_func(output, b_y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            scheduler.step(loss)
            lr = optimizer.param_groups[0]['lr']

            # with torch.no_grad():
            #     mse = torch.mean(((output-b_y)**2).flatten(1), dim=1)
            #     psnr_rect = 10 * torch.log10((maxVal - minVal) ** 2 / mse.cpu())
            #     # print(psnr_rect)
            #     mse = torch.mean(((b_y - b_x) ** 2).flatten(1), dim=1)
            #     psnr_ave = 10 * torch.log10((maxVal - minVal) ** 2 / mse.cpu())
            #     # print(psnr_ave)
            #     loss_PSNR = (psnr_rect - psnr_ave).mean().data

            viz.line(X=np.array([iter_count]), Y=np.array([dc_loss.cpu().data]), update='append', win=train_dc_win)
            viz.line(X=np.array([iter_count]), Y=np.array([ce_loss.cpu().data]), update='append', win=train_ce_win)
            viz.line(X=np.array([iter_count]), Y=np.array([loss.cpu().data]), update='append', win=train_loss_win)
            viz.line(X=np.array([epoch]), Y=np.array([lr]), update='append', win=lr_win)
            print('Epoch: %d | step: %d | loss: %.4f'%(epoch, step, loss.cpu().data))
        log_path = log + str(epoch) + '.pkl'
        torch.save(model.state_dict(), log_path)

def train_main(args, model, logdir):
    train_loader = triple_load_data(args.datadir, args.batch_size, args.context_num)
    optimizer = torch.optim.Adam(model.parameters(), args.learning_rate,
                                 weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=args.max_patience, factor=args.factor,
                                                           threshold=1e-7)
    # loss_func = torch.nn.L1Loss()
    loss_func = DC_and_CE_loss({'batch_dice': True, 'smooth': 1e-5, 'do_bg': False,
                                'square': False}, {})

    training_model(args, logdir, model, train_loader,
                   optimizer=optimizer, loss_func=loss_func, scheduler=scheduler)

def confusion_matrix(softmax_pred, gt_segmentation, global_fn=None, global_fp=None, global_tp=None):

    # print(softmax_pred.shape, gt_segmentation.shape)
    predicted_segmentation = softmax_pred.argmax(1)
    gt_segmentation = torch.squeeze(gt_segmentation.long())
    # y_onehot = torch.zeros(softmax_pred.shape)
    # if net_output.device.type == "cuda":
    #     y_onehot = y_onehot.cuda(net_output.device.index)
    # y_onehot.scatter_(1, gt_segmentation, 1)
    labels = [0,1,2,3,4,5,6]
    labels = [int(i) for i in labels if i > 0]
    # predicted_segmentation = np.expand_dims(predicted_segmentation.cpu().data.numpy(), 0)
    for l in labels:
        if l not in global_fn.keys():
            global_fn[l] = 0
        if l not in global_fp.keys():
            global_fp[l] = 0
        if l not in global_tp.keys():
            global_tp[l] = 0

        conf = ConfusionMatrix((predicted_segmentation.cpu().data.numpy() == l).astype(int),
                               (gt_segmentation.data.numpy() == l).astype(int))
        conf.compute()
        global_fn[l] += conf.fn
        global_fp[l] += conf.fp
        global_tp[l] += conf.tp

    print(global_fn, global_fp, global_tp)
    return global_fn, global_fp, global_tp

def eval(args, model, logdir, epoch):
    state_dict = torch.load(logdir+str(epoch)+'.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()
    for dir in os.listdir(args.testdir):
        with torch.no_grad():
            b_img = sitk.ReadImage(os.path.join(args.testdir, dir, 'axial_full_crop.nii.gz'))

            img_sa_arr = sitk.GetArrayFromImage(b_img)
            img_sa_arr = np.transpose(img_sa_arr, [2,1,0])
            img_sa_arr = np.expand_dims(img_sa_arr, axis=1)
            b_arr = img_sa_arr - np.min(img_sa_arr) / (np.max(img_sa_arr) - np.min(img_sa_arr))
            b_arr = torch.Tensor(b_arr)
            b_x = b_arr.cuda()  # reshape x to (batch, time_step, input_size)
            print(b_x.shape)
            # b_y = b_y.cuda()
            output = np.zeros(b_x.shape)
            for i in range(4):
                out = model(b_x[i*132:(i+1)*132, :, :, :]).cpu().data.numpy()
                print(out.shape)
                output[i*132:(i+1)*132, :, :, :] = out

            output = np.squeeze(output, axis=1)
            output = np.transpose(output, [2,1,0])
            full_a_arr_img = sitk.GetImageFromArray(output)
            full_a_arr_img.SetSpacing(b_img.GetSpacing())
            full_a_arr_img.SetOrigin(b_img.GetOrigin())
            full_a_arr_img.SetDirection(b_img.GetDirection())
            save_dir = args.resultdir + logdir.split('/')[-2]
            path_exist(save_dir)
            save_name = os.path.join(save_dir, dir+'_rect_'+str(epoch)+'.nii.gz')
            sitk.WriteImage(full_a_arr_img, save_name)
            del full_a_arr_img, output, b_img

def eval_tiff(args, file, model):
    # for dir in os.listdir(args.datadir):
    file_name = np.load(os.path.join(args.datadir, file))[0, :, :]  #'14535_9.npy'
    gt = np.load(os.path.join(args.datadir, file))[1, :, :]
    # gt = np.expand_dims(gt, axis=0)
    gt_tensor = torch.Tensor(np.expand_dims(gt, axis=0))

    file_arr = np.expand_dims(file_name, axis=0)
    file_arr = np.expand_dims(file_arr, axis=0)
    file_arr = (file_arr-np.min(file_arr))/(np.max(file_arr)-np.min(file_arr))
    file_tensor = torch.Tensor(file_arr).cuda()
    output = model(file_tensor)
    output = softmax_helper(output)
    global_dice = confusion_matrix(output, gt_tensor)
    return global_dice

    # save_dir = args.resultdir + logdir.split('/')[-2]+'/'
    # path_exist(save_dir)
    # imageio.imwrite(save_dir + '05270_7' + '_a.tiff', np.squeeze(output))
    # imageio.imwrite(save_dir + '05270_7' + '_sa.tiff', gt)

def get_img_param(img):
    spacing = img.GetSpacing()
    size = img.GetSize()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    arr = sitk.GetArrayFromImage(img)
    return  arr, spacing, size, origin, direction

def writeImg(arr, spacing, origin, direction, path):
    img = sitk.GetImageFromArray(arr)
    img.SetOrigin(origin)
    img.SetSpacing(spacing)
    img.SetDirection(direction)
    sitk.WriteImage(img, path)

def eval_func():
    pass

def eval_sample_nii(args, model, logdir, epoch, resultdir):
    state_dict = torch.load(logdir + str(epoch) + '.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()
    for file in os.listdir(args.test_nii_dir):
        num = file.split('_')[0]
        img_path = os.path.join(args.test_nii_dir, num, num+'_crop.nii.gz')
        img =sitk.ReadImage(img_path)
        img_arr, spacing, size, origin, direction = get_img_param(img)
        mask = np.zeros(img_arr.shape)
        datadir = os.path.join(args.test_npy_dir, num)
        n = 0

        test_loader = triple_load_data_test(datadir, args.batch_size, args.context_num, shuffle=False)
        for step, (b_x, b_y, minVal, maxVal) in enumerate(test_loader):
            b_x = b_x.cuda()
            b_x_num = len(b_x)
            n = n+b_x_num
            with torch.no_grad():
                output = model(b_x)
                output = output.argmax(dim=1)
            output =  np.transpose(output.cpu().data.numpy(),[1,2,0])
            mask[:, :, (args.context_num//2+step*args.batch_size):(args.context_num//2+step*args.batch_size)+b_x_num] =output

        # for i in range(size[0]):
        #     input = img_arr[:, :, i]
        #     input = (input-np.min(input))/(np.max(input)-np.min(input))
        #     file_arr = np.expand_dims(np.expand_dims(input, axis=0), axis=0)
        #     file_tensor = torch.Tensor(file_arr).cuda()
        #     output = model(file_tensor)
        #     output = output.argmax(dim=1)
        #     mask[:, :, i] = np.squeeze(output.cpu().data.numpy())
        print(n, )
        save_name = resultdir + num+'_crop_mask.nii.gz'
        writeImg(mask, spacing, origin, direction, save_name)

def eval_dice_npy(args, model, logdir, epoch,):
    state_dict = torch.load(logdir + str(epoch) + '.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()
    dice_loss = {}

    for file in os.listdir(args.testdir):
        npy_dice = eval_tiff(args, file, model)
        pass

def eval_sample_dice(args, model, logdir, epoch):
    state_dict = torch.load(logdir + str(epoch) + '.pkl', map_location='cuda:0')
    model.load_state_dict(state_dict)
    model.eval()
    num_list =[]
    flag = True
    global_tp = OrderedDict()
    global_fp = OrderedDict()
    global_fn = OrderedDict()
    global_dice = OrderedDict()

    train_loader = triple_load_data(args.datadir, args.batch_size, args.context_num, shuffle=False)
    with torch.no_grad():
        for step, (b_x, b_y, minVal, maxVal) in enumerate(train_loader):
            iter_count = epoch * len(train_loader) + step
            # gives batch data
            b_x = b_x.cuda()
            output = model(b_x)
            output = softmax_helper(output)
            global_fn, global_fp, global_tp = confusion_matrix(output, b_y, global_fn, global_fp, global_tp)

    labels = [0, 1, 2, 3, 4, 5, 6]
    labels = [int(i) for i in labels if i > 0]
    # predicted_segmentation = np.expand_dims(predicted_segmentation.cpu().data.numpy(), 0)
    for l in labels:
        if global_tp[l] == 0:
            global_dice[l] = 0
        else:
            global_dice[l] = 2 * global_tp[l] / (2 * global_tp[l] + global_fn[l] + global_fp[l])

    print(global_dice)

def get_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--rundir', default='/share/litong/knee/blur_seg/seg_log/', type=str)
    parser.add_argument('--datadir', default='/share/litong/knee/blur_seg/axial_npy/', type=str)
    # /share/litong/knee/blur_seg/coronal_seg_npy_train  /share/litong/knee/blur_seg/seg_crop_npy/ --down sample
    parser.add_argument('--test_nii_dir', default='/share/litong/knee/blur_seg/coronal_npy/coronal_seg_data_train/',
                        type=str)
    parser.add_argument('--test_npy_dir', default='/share/litong/knee/blur_seg/coronal_npy/train_data_all/',
                        type=str)
    parser.add_argument('--resultdir', default='/share/litong/knee/blur_seg/seg_log/result/',
                        type=str)
    parser.add_argument('--is_training', default=False, type=bool)
    parser.add_argument('--bilinear', default=False, type=bool)
    parser.add_argument('--gpu', default=1, type=int)  # action='store_true'
    parser.add_argument('--context_num', default=1, type=int)  # action='store_true'

    parser.add_argument('--learning_rate', default=3e-4, type=float)

    # parser.add_argument('--task', default='by', type=str)
    parser.add_argument('--seed', default=42, type=int)
    parser.add_argument('--weight_decay', default=3e-5, type=float)  # 0.01
    parser.add_argument('--EPOCH', default=100, type=int)
    parser.add_argument('--batch_size', default=80, type=int)
    parser.add_argument('--max_patience', default=30, type=int)
    parser.add_argument('--factor', default=0.8, type=float)

    parser.add_argument('--lambda_L1', type=float, default=1, \
                           help='weight for L1 loss')
    parser.add_argument('--lambda_gan', type=float, default=0, \
                           help='weight for gan loss')
    parser.add_argument('--lr', type=float, default=0.00002, \
                           help='learning rate')
    parser.add_argument('--imgsz', type=int, default=256, \
                           help='imgsz')
    parser.add_argument('--z_dim', type=int, default=512, \
                           help='hidden latent z dim')
    parser.add_argument('--ch_G', type=int, default=32, \
                           help='number of feature maps for generator (encoder-decoder)')
    parser.add_argument('--ch_D', type=int, default=64, \
                           help='number of feature maps for discriminator')
    parser.add_argument('--ch_io', type=int, default=1, \
                           help='number of channels for image')
    parser.add_argument('--layers_D', type=int, default=3, \
                           help='depth of conv for discriminator')
    return parser

if __name__ == '__main__':

    args = get_parser().parse_args()
    # print(args.task)
    # np.random.seed(args.seed)
    # torch.manual_seed(args.seed)
    # if args.gpu:
    #     torch.cuda.manual_seed_all(args.seed)

    os.makedirs(args.rundir, exist_ok=True)
    os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)

    model = unet.UNet(n_channels=args.context_num, n_classes=7, bilinear=args.bilinear)

    model.cuda()

    logdir = args.rundir + 'coronal_seg_triple_1/'
    resultdir = args.resultdir + '/coronal_seg_1_1/train/' #'/axial_seg1/test/'
    path_exist(resultdir)

    if args.is_training:
        if not os.path.exists(logdir):
            os.makedirs(logdir)

        with open(Path(logdir) / 'args.json', 'w') as out:
            json.dump(vars(args), out, indent=4)

        print(logdir)
        train_main(args, model, logdir)

    else:

        eval_sample_nii(args, model, logdir, 87, resultdir)
        # eval_sample_dice(args, model, logdir, 87)