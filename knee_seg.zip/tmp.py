import torch
import numpy as np

a = np.array([[[[[2,3,67],[5,6,7],[4,4,1]]]]])
b= torch.Tensor(a)

print(a.shape)