import numpy as np
import nibabel as nib
import csv
import math
import random
import os.path
import torch

def getSpacing(image):
    D = 3
    return image.get_header()['pixdim'][1:D+1]

def shape2verticesInd(shape, homogeneous=False):
    assert len(shape) == 3
    vertices = np.mgrid[0:2,0:2,0:2].reshape(3,-1).T*shape
    if homogeneous:
        vertices = np.concatenate([vertices, np.ones((8,1))], 1)
    return vertices

def build_affine(new_spacing, img):
    D = 3
    origin = [0, 0, 0]
    affine = np.eye(D + 1)
    affine[0:3, 3] += origin
    affine[:, 0:3] *= new_spacing / getSpacing(img)
    affineRef = img.affine @ affine
    return affineRef

def is_inside(image, affine, shape):
    img_shape = image.get_shape()
    img_affine = image.affine
    patch_vertex_in_image = \
            np.linalg.inv(img_affine) @ affine \
            @ shape2verticesInd(shape, homogeneous=True).T
    ind_pos = patch_vertex_in_image[:3,:]
    ind_neg = ind_pos - (np.array(img_shape) - 1).reshape(3,1)
    return ind_pos.min()>=0 and ind_neg.max()<=0

def crop(image, ranges, pad=[0,0,0], ratio=[1,1,1]):
    '''
    ranges: [[x_start, x_stop), [y_start, y_stop), [z_start, z_stop)]
    '''
    assert isinstance(image, nib.analyze.AnalyzeImage)
    #ranges = np.ceil(ranges).astype(np.int)
    shape = image.shape
    newRanges = []
    for r,p,s,n in zip(ranges, pad, shape, ratio):
        middle = (r[0]+r[1])/2.0
        length = math.ceil((r[1] - r[0] + p*2)/float(n))*n
        assert length <= s
        minVal = math.floor(max(middle-length/2.0, 0))
        maxVal = min(minVal+length, s)
        minVal = maxVal - length
        newRanges.append((minVal, maxVal))
    ranges = np.array(newRanges)
    data = image.get_data()
    affine = image.affine.copy()
    data = data[ranges[0,0]:ranges[0,1], \
            ranges[1,0]:ranges[1,1], ranges[2,0]:ranges[2,1]]
    origin = nib.affines.apply_affine(affine, ranges[:,0])
    affine[0:3,3] = origin
    return nib.Nifti1Image(data.copy(), affine)

def getVertices(image):
    shape = image.get_shape()
    affine = image.affine
    vertices = np.mgrid[0:2,0:2,0:2].reshape(3,-1).T*(np.array(shape)-1)
    vertices = np.concatenate([vertices, np.ones((8,1))], 1)
    return affine@vertices.T

def getIntersection(image, *constrains, strict=0):
    '''
    get common cube of a image and several constrains
        assuming they are orthogonal
    strict: (exactly intersection) 0 - 1 - 2 - 3 (rought intersection)
    return: a list of 2-tuple indicating
        the starting and ending index (with regard to image)
        of x,y,z seperately
    '''
    D = 3 # dimensionanlity
    N = 8 # number of vertices
    affine = np.array(image.affine)
    shape = np.array(image.get_shape())
    inv_affine = np.linalg.inv(affine)
    valid_ranges = np.array(list(zip([.0]*D, shape-1))) #x,y,z range seperately
    for constrain in constrains:
        vertices = inv_affine@getVertices(constrain).tolist()
        for dim in range(D):
            coord = sorted(vertices[dim])
            # print(coord)
            valid_ranges[dim,0] = \
                    max(valid_ranges[dim,0], coord[N//2-1-strict])
            valid_ranges[dim,1] = \
                    min(valid_ranges[dim,1], coord[N//2+strict])
    return valid_ranges

def getIntersectionMax(image, *constrains, strict=0):
    '''
    get common cube of a image and several constrains
        assuming they are orthogonal
    strict: (exactly intersection) 0 - 1 - 2 - 3 (rought intersection)
    return: a list of 2-tuple indicating
        the starting and ending index (with regard to image)
        of x,y,z seperately
    '''
    D = 3 # dimensionanlity
    N = 8 # number of vertices
    affine = np.array(image.affine)
    shape = np.array(image.get_shape())
    inv_affine = np.linalg.inv(affine)
    valid_ranges = np.array(list(zip([.0]*D, shape-1))) #x,y,z range seperately
    for constrain in constrains:
        vertices = inv_affine@getVertices(constrain).tolist()
        for dim in range(D):
            coord = sorted(vertices[dim])
            # print(coord)
            valid_ranges[dim,0] = \
                    min(valid_ranges[dim,0], coord[N//2-1-strict])
            valid_ranges[dim,1] = \
                    max(valid_ranges[dim,1], coord[N//2+strict])
    return valid_ranges

def affine2Grids(affine, image, basegrid):
    # shape shoud be in (x, y, z) order
    # basegrid = np.meshgrid( \
    #         *[np.arange(n) for n in shape], indexing='ij')
    # basegrid.append(np.ones_like(basegrid[0]))
    # basegrid = np.stack(basegrid).reshape(4,-1)
    grids = []
    shape = [basegrid.shape[1], basegrid.shape[2], basegrid.shape[3]]
    basegrid = basegrid.reshape(4, -1)
    grid = (np.linalg.inv(image.affine)@affine)@basegrid
    grid = grid[0:3,:].reshape(3,*shape)
    grid = grid/(np.array(image.get_shape())-1).reshape(3,1,1,1)*2 - 1
    invgrid = np.meshgrid( \
            *[np.arange(n) for n in image.get_shape()], indexing='ij')
    invgrid.append(np.ones_like(invgrid[0]))
    invgrid = np.stack(invgrid).reshape(4,-1)
    invgrid = (np.linalg.inv(affine)@image.affine)@invgrid
    invgrid = invgrid[0:3,:].reshape(3,*image.get_shape())
    invgrid = invgrid/(np.array(shape)-1).reshape(3,1,1,1)*2 - 1
    grids.append((grid.T, invgrid.T))
    return grids

def affine2Grids_original(affine, shape, *images):
    # shape shoud be in (x, y, z) order
    basegrid = np.meshgrid( \
            *[np.arange(n) for n in shape], indexing='ij')
    basegrid.append(np.ones_like(basegrid[0]))
    basegrid = np.stack(basegrid).reshape(4,-1)
    grids = []
    for image in images:
        grid = (np.linalg.inv(image.affine)@affine)@basegrid
        grid = grid[0:3,:].reshape(3,*shape)
        grid = grid/(np.array(image.get_shape())-1).reshape(3,1,1,1)*2 - 1
        invgrid = np.meshgrid( \
                *[np.arange(n) for n in image.get_shape()], indexing='ij')
        invgrid.append(np.ones_like(invgrid[0]))
        invgrid = np.stack(invgrid).reshape(4,-1)
        invgrid = (np.linalg.inv(affine)@image.affine)@invgrid
        invgrid = invgrid[0:3,:].reshape(3,*image.get_shape())
        invgrid = invgrid/(np.array(shape)-1).reshape(3,1,1,1)*2 - 1
        grids.append((grid.T, invgrid.T))

    return grids



def inflate(array, ratio, axis):
    outShape = list(array.shape)
    outShape[axis] *= ratio
    outShape[axis] -= (ratio-1)
    outArray = torch.zeros(outShape).to(array)
    select = [slice(None) for i in range(len(outShape))]
    select[axis] = slice(0,outShape[axis],ratio)
    outArray[select] = array
    return outArray

def mask2Grids(affine, shape, *images):
    # shape shoud be in (x, y, z) order
    basegrid = np.meshgrid( \
            *[np.arange(n) for n in shape], indexing='ij')
    basegrid.append(np.ones_like(basegrid[0]))
    basegrid = np.stack(basegrid).reshape(4,-1)
    grids = []

    for image in images:
        grid = (np.linalg.inv(image.affine)@affine)@basegrid
        grid = grid[0:3,:].reshape(3,*shape)
        grid = grid/(np.array(image.get_shape())-1).reshape(3,1,1,1)*2 - 1
        invgrid = np.meshgrid( \
                *[np.arange(n) for n in image.get_shape()], indexing='ij')
        invgrid.append(np.ones_like(invgrid[0]))
        invgrid = np.stack(invgrid).reshape(4,-1)
        invgrid = (np.linalg.inv(affine)@image.affine)@invgrid
        invgrid = invgrid[0:3,:].reshape(3,*image.get_shape())
        invgrid = invgrid/(np.array(shape)-1).reshape(3,1,1,1)*2 - 1
        grids.append((grid.T, invgrid.T))
    return grids

def align2RAS(image):
    # align (+x,+y,+z) to (R, A, S)
    eps = 1e-4
    data = image.get_data()
    affine = image.affine
    unitX, unitY, unitZ = list(map(lambda x: x/np.linalg.norm(x), \
            (affine[0:3,0], affine[0:3,1], affine[0:3,2])))
    # make sure it's square image
    assert  abs(unitX@unitY) < eps
    assert  abs(unitX@unitZ) < eps
    assert  abs(unitY@unitZ) < eps
    return nib.as_closest_canonical(image)


